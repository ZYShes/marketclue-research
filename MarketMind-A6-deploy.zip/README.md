---
title: MarketClue
emoji: 🔎
colorFrom: green
colorTo: gray
sdk: docker
app_port: 7860
---

# MarketClue — Assignment 6A

MarketClue is a student-developed adaptation of the Madison framework's MarketMind project (https://github.com/Humanitariansai/Madison/tree/main/MarketMind/Code). Product naming does not claim authorship of the upstream project. Existing technical identifiers retain their original names for compatibility.

Cross-category research interface: industry + question + optional 0–3 company names → real n8n execution → OpenAI web search → public webpage and optional YouTube comment collection → MarketMind evidence analysis → exact-quote verification → downloadable brief and evidence. With names omitted, discovery follows the market question and YouTube uses one industry/question search with up to ten comments; topic context is not attributed to a competitor. With names supplied, research focuses on those companies. Candidate suppliers are source-supported leads, not certified quality recommendations. GPT-6 Astra generates the analysis; there is no local AI fallback. The reptile catalog is an explicitly optional saved example.

MarketMind here is an adapted research backend based on the original project direction, not an execution of the upstream five-agent CrewAI implementation. n8n actually executes the six-node workflow in backend/workflow_live.json; its execution ID is recorded in each successful report. API credentials stay in the backend; the workflow receives only a temporary local stage token.

## Run locally

Install requirements into a virtual environment and run `npm install --omit=dev` inside backend. Run `python launch_live.py --use-existing-key --test-budget 5` only with the authorized A6 $5 allowance and the existing Neon budget connection configured. The local launcher uses the existing assignment3 n8n installation; set MARKETMIND_N8N_CLI to backend/node_modules/n8n/bin/n8n (absolute path) for a standalone installation. The launcher reads the existing A4 OpenAI key into process memory without copying it. All A6 calls share the existing durable ledger; never reset it to replenish the allowance. The migrated local ledger remains disabled when the Neon connection is missing. Open http://127.0.0.1:8507. Notes and reading preferences are per-session.

The October 26 local n8n launch stalled and remains unresolved. The source collectors and automated tests were validated separately; do not describe this local launcher as freshly verified. Cloud startup recovered and the workflow import reached readiness, as described below.

Discovery makes one OpenAI search call and considers at most 12 URLs. The analysis receives at most 36 evidence records: six page excerpts (up to 1,800 characters each) and all retained YouTube comments (at most 30, up to 1,200 characters each). The original captured comment records remain available in Sources and the evidence JSON download, along with collected webpages outside the analysis subset. Coverage reports page counts and comment counts separately. Including the full bounded comment sample avoids discarding useful statements merely because they appear later in API relevance order; it does not guarantee the model will interpret them correctly.

HTTPS and public DNS are required; redirects are checked and robots restrictions respected. Login-only, interactive, PDF and blocked pages are not collected. Firecrawl is an optional fallback for an accessible HTML page with insufficient extracted text, bounded to three pages per run. It is not used to bypass a robots failure, login or CAPTCHA. Failed sources and limited coverage are disclosed. Cross-category input does not guarantee exhaustive coverage of every industry, representative sentiment analysis, or up-to-date comparable prices. Source content is untrusted evidence, not executable instructions. Tracking parameters are removed to avoid duplicate citations. No paid retry occurs automatically.

The US$5 cap is deliberately conservative: a search reserves its worst-case context allowance before sending. A new task may be refused even with a small unspent balance. The ledger records estimates, not provider invoices. A workflow failure never publishes a substitute report.

## Source connections — October 26 upgrade

The existing YouTube credential was recovered and configured locally without displaying it. With the user's authorization, it was also saved in encrypted Streamlit Secrets while preserving the existing OpenAI and database credentials. No new account or subscription was created. Keep credentials server-side; never paste them into the research question or upload private configuration. The launcher accepts these environment settings, or allowlisted settings from local private configuration:

| Setting | Purpose | Default / limit |
| --- | --- | --- |
| `YOUTUBE_API_KEY` | Search relevant videos and read public top-level comments | Missing key produces an explicit `not_configured` status |
| `FIRECRAWL_API_KEY` | Optional webpage extraction provider | Disabled without a key or explicit anonymous opt-in |
| `FIRECRAWL_ALLOW_ANONYMOUS` | Explicitly opt into the provider's limited anonymous mode | Disabled unless set to `true`; successful pilot does not guarantee ongoing availability |
| `FIRECRAWL_MAX_FALLBACK_PAGES` | Bound provider requests per research run | At most 3; `0` disables fallback |
| `MARKETMIND_LEDGER_DATABASE_URL` | Existing shared Neon spending ledger | Required after migration for paid OpenAI calls; do not replace it with a fresh ledger |

The deployed settings explicitly enable limited anonymous Firecrawl with `FIRECRAWL_ALLOW_ANONYMOUS=true` and `FIRECRAWL_MAX_FALLBACK_PAGES=3`. No Firecrawl payment account or new paid provider subscription was created. This setting does not guarantee the provider's anonymous mode will remain available.

YouTube collects at most one relevance-ranked video and ten relevance-ranked top-level comments for each competitor. Replies are not collected. Comments include tutorial praise, promotion and questions as well as potential product experience; they must not all be described as customer reviews. Competitor association follows video search context. Purchaser status and commenter location are unverified. The UI and exported brief state these limits and distinguish collected records from records used in analysis.

The October 26 live collection pilot used three manually chosen official website URLs and three YouTube searches: Asana, Sony WH-1000XM6 and Zen Habitats. YouTube returned 28 comments and retained 27 (9 / 10 / 8). Direct HTML collection succeeded for Asana and Zen Habitats; anonymous Firecrawl extraction separately succeeded on those same two pages. Sony's webpage was not collected because its robots policy could not be verified; Firecrawl did not bypass that failure. This validates limited source access across three categories, not universal industry coverage or a new end-to-end AI report. No paid OpenAI request was made for this pilot, and the existing Neon ledger was not reset or changed by the upgrade tests.

A subjective Codex review of the 27 retained comments classified eight as potentially useful for category research, including four relevant to the focal product. Category-useful counts were 1 / 5 / 2 for software / headphones / enclosures; focal-product counts were 0 / 2 / 2. Alternative products, older generations and broad category issues were kept distinct from focal-product evidence. This excerpt-based pilot judgment is not independently validated accuracy, customer sentiment, or a representative quality estimate. Two borderline reptile comments were conservatively excluded. The result motivated including all retained comments in the bounded analysis packet rather than only the first six. No new paid AI report has yet verified that change end to end.

Read the Chinese [upgrade report](evidence/source-upgrade-20261026.html), [YouTube collection evidence](evidence/youtube-cross-category-pilot-20261026.json) and [web extraction evidence](evidence/web-source-pilot-20261026.json). The website URLs were selected in advance; this pilot did not retest the automatic OpenAI discovery stage. Initial restricted-environment YouTube attempts failed and are retained separately in the evidence rather than counted as successful collections.

## Deployment status

A public deployment exists at https://marketmind-zyshes.streamlit.app/ with source at https://github.com/ZYShes/marketmind-research. On October 22, a full cloud Asana/Basecamp run succeeded: 12 candidate pages, eight readable pages, six analyzed pages and four findings. Its HTML report is saved in `evidence/cloud-live-research-brief.html`. The existing shared Neon allowance survived a full reboot and reconnected session. Cold starts can take several minutes; long-term reliability and independent tester access are not established by that single run.

**October 26 source upgrade: published; cloud source configuration and startup verified.** The application ZIP was published in commit `4e97b688e64b6be59c37201b23368a6caa5cd12c`; the cloud startup wrapper correction was published in `da85ee72d96551fe4e6397a4624536a174c3bb14`. At 18:29 UTC the public UI was ready, displayed “YouTube comments: connected,” and showed USD3.17 remaining of the existing USD5 allowance. n8n import readiness was confirmed after hot reload. No paid OpenAI request was made during this upgrade, and the existing budget ledger was not reset.

A fresh full reboot from 18:29 to 18:34 UTC succeeded. The platform installed 2,421 npm packages in approximately three minutes, then the cloud backend and n8n import reached readiness. After onboarding and navigation back to Research, the UI still showed “YouTube comments: connected” and USD3.17 remaining of USD5. Screenshot: `evidence/cloud-source-upgrade-20261026.png`. This cold start took approximately five minutes; one successful reboot does not establish long-term availability.

A new end-to-end cloud AI report using mixed webpage/comment evidence has not been generated or verified. The live source pilots and visible connection state establish different things: the pilots demonstrate bounded source access; the public UI confirms the source configuration is present. Neither should be presented as an already verified new full AI research report. No paid calls were made for the reboot verification.

Docker hosting requires server-side OPENAI_API_KEY, the existing MARKETMIND_LEDGER_DATABASE_URL and an explicitly authorized OPENAI_TEST_BUDGET_USD. This test release caps the allowance at $5. Before a longer public test period, separately authorize an appropriate budget. Ephemeral container replacement must not reset the shared spending allowance. No hosting purchase is authorized or completed.

Only allowlisted application files belong in deployment. Never upload A4's .env.local, node_modules, model cache, private ledger, logs, or tester identities. The Dockerfile explicitly copies application sources; .dockerignore excludes private/runtime files.

## Verification and submission

Evidence in evidence/ records only checks actually performed. Recorded participant feedback informed the October 22 interface revision; retesting and non-classmate eligibility remain unverified in the deployment handoff. Automated tests do not replace real participant sessions. Final PDF must include the public URL, 300–400-word walkthrough, three interface screenshots, real test findings and decisions, four-tool positioning diagram and a revised statement tied to those findings.

Upgrade verification: the full 54-test Node suite passed, followed by one additional analysis test; 20 Python tests passed. These checks cover bounded collection, source configuration, evidence analysis handling and UI/export behavior. They do not establish external-service uptime, representative research quality or a newly generated cloud AI report.

Neon Free holds the migrated shared budget (8 entries, USD1.0167 before cloud testing; 10 entries, USD1.30964 after the October 22 run). These are historical totals. The October 26 18:29 UTC public UI showed USD3.17 remaining of USD5; do not reuse the historical USD3.69 balance as the current value. No paid calls were made for the October 26 upgrade. The owner authorized encrypted Streamlit Secrets for the API/database credentials. The stale local ledger is disabled by a migration marker; never remove it to restore allowance. Latest deployment evidence and unresolved issues are tracked in deployment/STREAMLIT-HANDOFF.txt.
