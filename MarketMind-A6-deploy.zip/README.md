---
title: MarketMind Commerce Insights
emoji: 🔎
colorFrom: green
colorTo: gray
sdk: docker
app_port: 7860
---

# Assignment 6A — MarketMind

Cross-category research interface: industry + 1–3 competitor names + question → real n8n execution → OpenAI web search → public HTML collection → MarketMind evidence analysis → exact-quote verification → downloadable brief. GPT-6 Astra generates the analysis; there is no local AI fallback. The reptile catalog is an explicitly optional saved example.

MarketMind here is an adapted research backend based on the original project direction, not an execution of the upstream five-agent CrewAI implementation. n8n actually executes the six-node workflow in backend/workflow_live.json; its execution ID is recorded in each successful report. API credentials stay in the backend; the workflow receives only a temporary local stage token.

## Run locally

Install requirements into a virtual environment and run `npm install --omit=dev` inside backend. Run `python launch_live.py --use-existing-key --test-budget 5` only with the authorized A6 $5 allowance. The local launcher uses the existing assignment3 n8n installation; set MARKETMIND_N8N_CLI to backend/node_modules/n8n/bin/n8n (absolute path) for a standalone installation. The launcher reads the existing A4 key into process memory without copying it. All A6 calls share the existing durable ledger; never reset it to replenish the allowance. Open http://127.0.0.1:8507. Notes and reading preferences are per-session.

Discovery makes one search call, considers at most 12 URLs, and analyzes at most six collected excerpts. HTTPS and public DNS are required; redirects are checked and robots restrictions respected. Login-only, interactive, PDF and blocked pages are not collected. Failed sources and limited coverage are disclosed. Cross-category input does not guarantee exhaustive coverage of every industry, reliable sentiment analysis, or up-to-date comparable prices. Source content is untrusted evidence, not executable instructions. Tracking parameters are removed to avoid duplicate citations. No paid retry occurs automatically.

The US$5 cap is deliberately conservative: a search reserves its worst-case context allowance before sending. A new task may be refused even with a small unspent balance. The ledger records estimates, not provider invoices. A workflow failure never publishes a substitute report.

## Deployment status

Not publicly deployed yet. The owner has no hosting account. Dockerfile and public Streamlit entrypoint are prepared; container execution and external anonymous access still require verification. Do not submit localhost as the tool URL.

Docker hosting requires server-side OPENAI_API_KEY and an explicitly authorized OPENAI_TEST_BUDGET_USD. This test release caps the allowance at $5. Before a longer public test period, configure durable storage for backend/.private and authorize an appropriate budget. Ephemeral container replacement must not reset a spending allowance. Select a host with persistent storage and a service that remains available through grading. No hosting purchase is authorized or completed.

Only allowlisted application files belong in deployment. Never upload A4's .env.local, node_modules, model cache, private ledger, logs, or tester identities. The Dockerfile explicitly copies application sources; .dockerignore excludes private/runtime files.

## Verification and submission

Evidence in evidence/ records only checks actually performed. Real user testing remains outstanding. Use the testing worksheet for three actual non-classmate testers; do not replace those sessions with automated tests. Final PDF must include the public URL, 300–400-word walkthrough, three interface screenshots, real test findings and decisions, four-tool positioning diagram and a revised statement tied to those findings.
