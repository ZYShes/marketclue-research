---
title: MarketMind Commerce Insights
emoji: 🔎
colorFrom: green
colorTo: gray
sdk: docker
app_port: 7860
---

# Assignment 6A — MarketMind

Cross-category research interface: industry + 1–3 competitor names + question → real n8n execution → OpenAI web search → public webpage and optional YouTube comment collection → MarketMind evidence analysis → exact-quote verification → downloadable brief and evidence. GPT-6 Astra generates the analysis; there is no local AI fallback. The reptile catalog is an explicitly optional saved example.

MarketMind here is an adapted research backend based on the original project direction, not an execution of the upstream five-agent CrewAI implementation. n8n actually executes the six-node workflow in backend/workflow_live.json; its execution ID is recorded in each successful report. API credentials stay in the backend; the workflow receives only a temporary local stage token.

## Run locally

Install requirements into a virtual environment and run `npm install --omit=dev` inside backend. Run `python launch_live.py --use-existing-key --test-budget 5` only with the authorized A6 $5 allowance and the existing Neon budget connection configured. The local launcher uses the existing assignment3 n8n installation; set MARKETMIND_N8N_CLI to backend/node_modules/n8n/bin/n8n (absolute path) for a standalone installation. The launcher reads the existing A4 OpenAI key into process memory without copying it. All A6 calls share the existing durable ledger; never reset it to replenish the allowance. The migrated local ledger remains disabled when the Neon connection is missing. Open http://127.0.0.1:8507. Notes and reading preferences are per-session.

Discovery makes one OpenAI search call and considers at most 12 URLs. The analysis receives at most 36 evidence records: six page excerpts (up to 1,800 characters each) and all retained YouTube comments (at most 30, up to 1,200 characters each). The original captured comment records remain available in Sources and the evidence JSON download, along with collected webpages outside the analysis subset. Coverage reports page counts and comment counts separately. Including the full bounded comment sample avoids discarding useful statements merely because they appear later in API relevance order; it does not guarantee the model will interpret them correctly.

HTTPS and public DNS are required; redirects are checked and robots restrictions respected. Login-only, interactive, PDF and blocked pages are not collected. Firecrawl is an optional fallback for an accessible HTML page with insufficient extracted text, bounded to three pages per run. It is not used to bypass a robots failure, login or CAPTCHA. Failed sources and limited coverage are disclosed. Cross-category input does not guarantee exhaustive coverage of every industry, representative sentiment analysis, or up-to-date comparable prices. Source content is untrusted evidence, not executable instructions. Tracking parameters are removed to avoid duplicate citations. No paid retry occurs automatically.

The US$5 cap is deliberately conservative: a search reserves its worst-case context allowance before sending. A new task may be refused even with a small unspent balance. The ledger records estimates, not provider invoices. A workflow failure never publishes a substitute report.

## Source connections — local upgrade, October 26

The existing YouTube credential was recovered and configured locally without displaying it. No new account or subscription was created. Keep credentials server-side; never paste them into the research question or upload private configuration. The launcher accepts these environment settings, or allowlisted settings from local private configuration:

| Setting | Purpose | Default / limit |
| --- | --- | --- |
| `YOUTUBE_API_KEY` | Search relevant videos and read public top-level comments | Missing key produces an explicit `not_configured` status |
| `FIRECRAWL_API_KEY` | Optional webpage extraction provider | Disabled without a key or explicit anonymous opt-in |
| `FIRECRAWL_ALLOW_ANONYMOUS` | Explicitly opt into the provider's limited anonymous mode | Disabled unless set to `true`; successful pilot does not guarantee ongoing availability |
| `FIRECRAWL_MAX_FALLBACK_PAGES` | Bound provider requests per research run | At most 3; `0` disables fallback |
| `MARKETMIND_LEDGER_DATABASE_URL` | Existing shared Neon spending ledger | Required after migration for paid OpenAI calls; do not replace it with a fresh ledger |

YouTube collects at most one relevance-ranked video and ten relevance-ranked top-level comments for each competitor. Replies are not collected. Comments include tutorial praise, promotion and questions as well as potential product experience; they must not all be described as customer reviews. Competitor association follows video search context. Purchaser status and commenter location are unverified. The UI and exported brief state these limits and distinguish collected records from records used in analysis.

The October 26 live collection pilot used three manually chosen official website URLs and three YouTube searches: Asana, Sony WH-1000XM6 and Zen Habitats. YouTube returned 28 comments and retained 27 (9 / 10 / 8). Direct HTML collection succeeded for Asana and Zen Habitats; anonymous Firecrawl extraction separately succeeded on those same two pages. Sony's webpage was not collected because its robots policy could not be verified; Firecrawl did not bypass that failure. This validates limited source access across three categories, not universal industry coverage or a new end-to-end AI report. No paid OpenAI request was made for this pilot, and the existing Neon ledger was not reset or changed by the upgrade tests.

A subjective Codex review of the 27 retained comments classified eight as potentially useful for category research, including four relevant to the focal product. Category-useful counts were 1 / 5 / 2 for software / headphones / enclosures; focal-product counts were 0 / 2 / 2. Alternative products, older generations and broad category issues were kept distinct from focal-product evidence. This excerpt-based pilot judgment is not independently validated accuracy, customer sentiment, or a representative quality estimate. Two borderline reptile comments were conservatively excluded. The result motivated including all retained comments in the bounded analysis packet rather than only the first six. No new paid AI report has yet verified that change end to end.

Read the Chinese [upgrade report](evidence/source-upgrade-20261026.html), [YouTube collection evidence](evidence/youtube-cross-category-pilot-20261026.json) and [web extraction evidence](evidence/web-source-pilot-20261026.json). The website URLs were selected in advance; this pilot did not retest the automatic OpenAI discovery stage. Initial restricted-environment YouTube attempts failed and are retained separately in the evidence rather than counted as successful collections.

## Deployment status

A public deployment exists at https://marketmind-zyshes.streamlit.app/ with source at https://github.com/ZYShes/marketmind-research. On October 22, a full cloud Asana/Basecamp run succeeded: 12 candidate pages, eight readable pages, six analyzed pages and four findings. Its HTML report is saved in `evidence/cloud-live-research-brief.html`. The existing shared Neon allowance survived a full reboot and reconnected session. Cold starts can take several minutes; long-term reliability and independent tester access are not established by that single run.

**October 26 source upgrade: implemented and tested locally; publication is pending.** The public application has not yet been verified with the new YouTube/Firecrawl collection and evidence downloads. Do not present local pilot results as proof that the public deployment already contains this upgrade. Cloud rollout also requires the source settings to be configured in encrypted Streamlit Secrets. Anonymous Firecrawl remains off unless explicitly enabled.

Docker hosting requires server-side OPENAI_API_KEY, the existing MARKETMIND_LEDGER_DATABASE_URL and an explicitly authorized OPENAI_TEST_BUDGET_USD. This test release caps the allowance at $5. Before a longer public test period, separately authorize an appropriate budget. Ephemeral container replacement must not reset the shared spending allowance. No hosting purchase is authorized or completed.

Only allowlisted application files belong in deployment. Never upload A4's .env.local, node_modules, model cache, private ledger, logs, or tester identities. The Dockerfile explicitly copies application sources; .dockerignore excludes private/runtime files.

## Verification and submission

Evidence in evidence/ records only checks actually performed. Recorded participant feedback informed the October 22 interface revision; retesting and non-classmate eligibility remain unverified in the deployment handoff. Automated tests do not replace real participant sessions. Final PDF must include the public URL, 300–400-word walkthrough, three interface screenshots, real test findings and decisions, four-tool positioning diagram and a revised statement tied to those findings.

Neon Free holds the migrated shared budget (8 entries, USD1.0167 before cloud testing; 10 entries, USD1.30964 after the October 22 run). These are recorded historical totals, not a fresh balance check. The owner authorized encrypted Streamlit Secrets for the API/database credentials. The stale local ledger is disabled by a migration marker; never remove it to restore allowance. Latest deployment evidence and unresolved issues are tracked in deployment/STREAMLIT-HANDOFF.txt.
