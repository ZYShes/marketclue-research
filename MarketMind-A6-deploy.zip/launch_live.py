"""Launch n8n-backed MarketMind and Streamlit; credentials stay server-side."""
import argparse, os, secrets, subprocess, sys, time, urllib.request, json
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--use-existing-key',action='store_true')
    parser.add_argument('--test-budget',type=float,default=0)
    parser.add_argument('--port',type=int,default=8507)
    args=parser.parse_args()
    if not 0<=args.test_budget<=5: parser.error('The authorized test allowance is at most US$5.')
    env=dict(os.environ)
    if args.use_existing_key:
        for line in (ROOT.parent/'assignment4/.env.local').read_text(encoding='utf-8-sig').splitlines():
            if line.startswith('OPENAI_API_KEY='):env.setdefault('OPENAI_API_KEY',line.split('=',1)[1].strip())
    env.update(MARKETMIND_GATEWAY_TOKEN=secrets.token_hex(32),MARKETMIND_PYTHON=sys.executable,
               MARKETMIND_N8N_CLI=env.get('MARKETMIND_N8N_CLI',str(ROOT.parent/'assignment3/node_modules/n8n/bin/n8n')),
               OPENAI_MODEL='gpt-6-astra',OPENAI_REASONING_EFFORT='medium',OPENAI_MAX_OUTPUT_TOKENS='5000',OPENAI_TEST_BUDGET_USD=str(args.test_budget))
    backend=subprocess.Popen(['node','live-server.mjs'],cwd=ROOT/'backend',env=env)
    ui=None
    try:
        for _ in range(100):
            if backend.poll() is not None: raise RuntimeError('MarketMind backend stopped.')
            try:
                with urllib.request.urlopen('http://127.0.0.1:5683/health',timeout=2) as response:
                    if json.load(response).get('ready'):break
            except OSError:pass
            time.sleep(1)
        else: raise RuntimeError('n8n did not become ready. Inspect the private import log.')
        ui_env=dict(env);ui_env.pop('OPENAI_API_KEY',None)
        ui=subprocess.Popen([sys.executable,'-m','streamlit','run','app.py','--server.address=127.0.0.1','--server.port='+str(args.port),'--server.headless=true','--browser.gatherUsageStats=false'],cwd=ROOT,env=ui_env)
        print('Live MarketMind interface: http://127.0.0.1:'+str(args.port),flush=True)
        while backend.poll() is None and ui.poll() is None:time.sleep(1)
    finally:
        for process in (ui,backend):
            if process and process.poll() is None:process.terminate();process.wait(timeout=15)

if __name__=='__main__':main()
