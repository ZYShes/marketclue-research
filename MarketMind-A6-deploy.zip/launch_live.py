"""Launch n8n-backed MarketMind and Streamlit; credentials stay server-side."""
import argparse, os, secrets, subprocess, sys, time, urllib.request, json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PRIVATE_ENV_KEYS=('OPENAI_API_KEY','MARKETMIND_LEDGER_DATABASE_URL','YOUTUBE_API_KEY','FIRECRAWL_API_KEY')
SOURCE_ENV_KEYS=('YOUTUBE_API_KEY','FIRECRAWL_API_KEY','FIRECRAWL_ALLOW_ANONYMOUS','FIRECRAWL_MAX_FALLBACK_PAGES')


def env_file_values(path, allowed_names):
    """Read only allowlisted settings; do not execute or expand dotenv contents."""
    if not path.is_file():
        return {}
    values={}
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        line=line.strip()
        if line.startswith('export '):
            line=line[7:].lstrip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        name,value=line.split('=',1)
        name=name.strip()
        if name not in allowed_names:
            continue
        value=value.strip()
        if len(value)>=2 and value[0]==value[-1] and value[0] in ('"', "'"):
            value=value[1:-1]
        values[name]=value
    return values


def load_source_env(env):
    # Existing environment wins; assignment6 settings win over the legacy YouTube fallback.
    for path,names in ((ROOT/'backend/.env.local',SOURCE_ENV_KEYS),
                       (ROOT/'.env.local',SOURCE_ENV_KEYS),
                       (ROOT.parent/'assignment4/.env.local',('YOUTUBE_API_KEY',))):
        for name,value in env_file_values(path,names).items():
            env.setdefault(name,value)
    return env

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--use-existing-key',action='store_true')
    parser.add_argument('--test-budget',type=float,default=0)
    parser.add_argument('--port',type=int,default=8507)
    args=parser.parse_args()
    if not 0<=args.test_budget<=5: parser.error('The authorized test allowance is at most US$5.')
    env=load_source_env(dict(os.environ))
    if args.use_existing_key:
        for name,value in env_file_values(ROOT.parent/'assignment4/.env.local',('OPENAI_API_KEY',)).items():
            env.setdefault(name,value)
    env.update(MARKETMIND_GATEWAY_TOKEN=secrets.token_hex(32),MARKETMIND_PYTHON=sys.executable,
               MARKETMIND_N8N_CLI=env.get('MARKETMIND_N8N_CLI',str(ROOT.parent/'assignment3/node_modules/n8n/bin/n8n')),
               N8N_COMMUNITY_PACKAGES_ENABLED='false',
               OPENAI_MODEL='gpt-6-astra',OPENAI_REASONING_EFFORT='medium',OPENAI_MAX_OUTPUT_TOKENS='5000',OPENAI_TEST_BUDGET_USD=str(args.test_budget))
    backend=subprocess.Popen(['node','live-server.mjs'],cwd=ROOT/'backend',env=env)
    ui=None
    try:
        for _ in range(100):
            if backend.poll() is not None: raise RuntimeError('MarketMind backend stopped.')
            try:
                with urllib.request.urlopen('http://127.0.0.1:5683/health',timeout=2) as response:
                    if json.load(response).get('ready'):break
            except OSError:pass
            time.sleep(1)
        else: raise RuntimeError('n8n did not become ready. Inspect the private import log.')
        ui_env={name:value for name,value in env.items() if name not in PRIVATE_ENV_KEYS}
        ui=subprocess.Popen([sys.executable,'-m','streamlit','run','app.py','--server.address=127.0.0.1','--server.port='+str(args.port),'--server.headless=true','--browser.gatherUsageStats=false'],cwd=ROOT,env=ui_env)
        print('Live MarketMind interface: http://127.0.0.1:'+str(args.port),flush=True)
        while backend.poll() is None and ui.poll() is None:time.sleep(1)
    finally:
        for process in (ui,backend):
            if process and process.poll() is None:process.terminate();process.wait(timeout=15)

if __name__=='__main__':main()
