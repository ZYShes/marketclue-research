"""Container entrypoint. Only Streamlit is public; the API binds loopback."""
import os
import subprocess
import sys
import time
import secrets
from pathlib import Path

environment = dict(os.environ)
# Hosted paid calls require the existing ledger on a verified persistent mount.
# Never create a fresh allowance simply because a container was rebuilt.
if float(environment.get('OPENAI_TEST_BUDGET_USD','0')) > 0:
    ledger=environment.get('MARKETMIND_LEDGER_DIR','')
    if not ledger or not (Path(ledger)/'ledger.json').is_file() or not (Path(ledger)/'initialized').is_file():
        raise SystemExit('Hosted research requires the migrated budget ledger on persistent storage. Configure MARKETMIND_LEDGER_DIR before enabling API usage.')
environment['MARKETMIND_GATEWAY_TOKEN']=secrets.token_hex(32)
environment['MARKETMIND_PYTHON']=sys.executable
environment['MARKETMIND_N8N_CLI']=str(Path('backend/node_modules/n8n/bin/n8n').resolve())
backend = subprocess.Popen(["node", "live-server.mjs"], cwd="backend",env=environment)
environment.pop("OPENAI_API_KEY", None)
ui = subprocess.Popen([sys.executable, "-m", "streamlit", "run", "app.py", "--server.address=0.0.0.0", "--server.port=7860"], env=environment)
try:
    while backend.poll() is None and ui.poll() is None:
        time.sleep(1)
finally:
    for process in (backend, ui):
        if process.poll() is None:
            process.terminate()
    for process in (backend, ui):
        process.wait(timeout=15)
