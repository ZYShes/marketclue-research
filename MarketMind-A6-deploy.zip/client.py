"""Server-side transport and accessible, self-contained review export."""
import html
import json
import os
import urllib.error
import urllib.request
import uuid
import time

BASE = os.environ.get("MARKETMIND_BACKEND", "http://127.0.0.1:5682")


class ResearchError(Exception):
    pass


def research_budget(industry, competitors, query):
    token=os.environ.get('MARKETMIND_GATEWAY_TOKEN','')
    if not token:return None
    base=os.environ.get('MARKETMIND_LIVE_BACKEND','http://127.0.0.1:5683')
    try:
        try:
            data=validate_live_input(industry,competitors,query)
        except ResearchError:
            data=None
        req=urllib.request.Request(base+('/preflight' if data else '/status'),
            data=json.dumps(data).encode() if data else None,
            headers={'Content-Type':'application/json','X-MarketMind-Token':token})
        with urllib.request.urlopen(req,timeout=3) as response:return json.load(response)
    except (OSError,ValueError):return None


def validate_live_input(industry, competitors, query):
    if not isinstance(industry,str) or not 2 <= len(industry.strip()) <= 120:
        raise ResearchError('Enter an industry or product category (2–120 characters).')
    names=[x.strip() for x in competitors.splitlines() if x.strip()]
    if not 1 <= len(names) <= 3 or any(not 2 <= len(x) <= 100 for x in names):
        raise ResearchError('Enter one to three competitor names, one per line (2–100 characters each).')
    if len(set(x.casefold() for x in names)) != len(names):
        raise ResearchError('Use distinct competitor names, one per line.')
    return {'industry':industry.strip(),'competitors':names,'query':validate_query(query)}


def analyze_live(industry, competitors, query, on_progress=lambda message: None):
    data=validate_live_input(industry,competitors,query)
    token=os.environ.get('MARKETMIND_GATEWAY_TOKEN','')
    if not token:raise ResearchError('Live research is not connected. Start the n8n-backed MarketMind service; the example remains available.')
    base=os.environ.get('MARKETMIND_LIVE_BACKEND','http://127.0.0.1:5683')
    def request(path,payload=None):
        req=urllib.request.Request(base+path,data=None if payload is None else json.dumps(payload).encode(),headers={'Content-Type':'application/json','X-MarketMind-Token':token})
        try:
            with urllib.request.urlopen(req,timeout=20) as response:return json.load(response)
        except urllib.error.HTTPError as error:
            try:message=json.loads(error.read()).get('error','Research service could not complete the request.')
            except (ValueError,UnicodeError):message='Research service could not complete the request.'
            raise ResearchError(message) from None
        except (OSError,ValueError):raise ResearchError('The research service is unavailable. Your input is kept. No automatic paid retry was made.') from None
    job=request('/research',data)['job_id']
    deadline=time.monotonic()+620
    while time.monotonic()<deadline:
        result=request('/jobs/'+job)
        on_progress(result['message'])
        if result['state']=='complete':
            report=result.get('report',{})
            generated=report.get('generated_analysis',{})
            if report.get('mode')!='live' or generated.get('provider')!='openai' or not generated.get('validation',{}).get('citations_valid') or report.get('workflow',{}).get('exit_code')!=0:
                raise ResearchError('The completed research could not be verified. No replacement report was published.')
            return report
        if result['state']=='failed':raise ResearchError(result['message'])
        time.sleep(1.5)
    raise ResearchError('Research is taking longer than expected. The original task may still finish; do not submit a duplicate immediately.')


def validate_query(query):
    if not 8 <= len(query.strip()) <= 600:
        raise ResearchError("Enter a research question between 8 and 600 characters. For example: Compare their positioning and features.")
    return query.strip()


def analyze(query):
    query = validate_query(query)
    payload = {"query": query, "analysis_provider": "openai", "save": False,
               "request_id": "a6-" + uuid.uuid4().hex}
    request = urllib.request.Request(BASE + "/analyze", data=json.dumps(payload).encode(),
                                     headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=150) as response:
            result = json.load(response)
    except urllib.error.HTTPError as error:
        try:
            code = json.loads(error.read()).get("code", "")
        except (ValueError, UnicodeError):
            code = ""
        if code in {"OPENAI_NOT_CONFIGURED", "OPENAI_BUDGET_DISABLED", "OPENAI_BUDGET_EXCEEDED"} or error.code == 402:
            message = "Analysis is temporarily unavailable while the owner finishes service setup or renews its allowance. Your question is still here. Please contact the owner and try again later."
        elif error.code == 429:
            message = "The research service is busy. Wait a moment, then select Generate research brief again. Your question has been kept."
        elif code in {"OPENAI_INVALID_OUTPUT", "OPENAI_INCOMPLETE"}:
            message = "The AI response did not pass our completeness or source checks. No new brief was published. Please try again or make your question more specific."
        else:
            message = "The analysis could not finish. Your question has been kept. Please try again later; if the problem continues, contact the owner."
        raise ResearchError(message) from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise ResearchError("The research service could not be reached in time. Your question has been kept. Wait a moment and try again; no replacement analysis was generated.") from None
    except (ValueError, UnicodeError):
        raise ResearchError("The research service returned an unreadable response. Please try again later.") from None
    report = result.get("report", {})
    generated = report.get("generated_analysis", {})
    if not result.get("ok") or generated.get("provider") != "openai" or not generated.get("validation", {}).get("citations_valid"):
        raise ResearchError("The analysis could not be verified. No new brief was published. Please try again later.")
    return report


def export_html(report, notes):
    e = lambda value: html.escape(str(value), quote=True)
    content = report["generated_analysis"]["content"]
    rows = {row["record_id"]: row for row in report["selected"]}
    parts = ["<!doctype html><html lang='en'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>MarketMind research brief</title>",
             "<style>body{font:18px/1.65 system-ui,sans-serif;color:#172b28;background:#fafaf7;max-width:850px;margin:auto;padding:24px}a{color:#174d43;text-decoration:underline}a:focus-visible{outline:3px solid #9c3d10;outline-offset:4px}section{border-top:1px solid #778a81;padding:16px 0}blockquote{border-left:4px solid #174d43;padding-left:16px}pre{white-space:pre-wrap;font:inherit;overflow-wrap:anywhere}@media print{body{font-size:12pt}}</style><main><h1>MarketMind research brief</h1>",
             f"<p><strong>Question:</strong> {e(report['query'])}</p>",
             f"<p>Generated {e(report['generated_at'])} using {e(report['generated_analysis']['model'])}. {'Public sources collected for this request; collection dates appear below.' if report.get('mode') == 'live' else 'Saved example: October 2, 2026 snapshot. Prices are historical.'}</p>",
             f"<section><h2>Summary — {e(content['answer_status'].replace('_',' '))}</h2><p>{e(content['summary'])}</p></section>"]
    for finding in content["findings"]:
        parts.append(f"<section><h2>{e(finding['title'])}</h2><p><strong>{e(finding['kind'].replace('_',' '))}</strong></p><p>{e(finding['analysis'])}</p><p><strong>Limit:</strong> {e(finding['caveat'])}</p>")
        for citation in finding["evidence"]:
            row = rows[citation["record_id"]]
            parts.append(f"<blockquote>{e(citation['quote'])}</blockquote><p><a href='{e(row['source_url'])}'>{e(row['source'])}: {e(row['title'])}</a> — {e(citation['field'])}. Collected {e(row.get('captured_at','unknown'))}</p>")
        parts.append("</section>")
    parts.append("<section><h2>Recommended next steps</h2><ol>")
    for item in content["recommendations"]:
        parts.append(f"<li>{e(item['action'])}<p>{e(item['rationale'])}</p><p><strong>Verify:</strong> {e(item['validation_step'])}</p></li>")
    parts.append("</ol><h2>Missing evidence</h2><ul>")
    parts.extend(f"<li>{e(gap)}</li>" for gap in content["research_gaps"])
    parts.append("</ul></section><section><h2>Product comparison checks</h2>")
    for finding in report.get("decision_audit", {}).get("findings", []):
        parts.append(f"<h3>{e(finding['title'])}</h3><p>{e(finding['claim'])}</p><p><strong>Next check:</strong> {e(finding['next_action'])}</p>")
    parts.append(f"</section><section><h2>Your review notes — not AI-verified</h2><pre>{e(notes or 'No review notes added.')}</pre></section><p>Quotes were checked against saved records. Interpretations and recommendations still require human review.</p></main></html>")
    return "\n".join(parts)
