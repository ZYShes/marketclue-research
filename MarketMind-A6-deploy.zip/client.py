"""Server-side transport and accessible, self-contained review export."""
import html
import json
import os
import urllib.error
import urllib.request
import uuid
import time
import re
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

BASE = os.environ.get("MARKETMIND_BACKEND", "http://127.0.0.1:5682")


class ResearchError(Exception):
    pass


def research_budget(industry, competitors, query):
    token=os.environ.get('MARKETMIND_GATEWAY_TOKEN','')
    if not token:return None
    base=os.environ.get('MARKETMIND_LIVE_BACKEND','http://127.0.0.1:5683')
    try:
        try:
            data=validate_live_input(industry,competitors,query)
        except ResearchError:
            data=None
        req=urllib.request.Request(base+('/preflight' if data else '/status'),
            data=json.dumps(data).encode() if data else None,
            headers={'Content-Type':'application/json','X-MarketMind-Token':token})
        with urllib.request.urlopen(req,timeout=3) as response:return json.load(response)
    except (OSError,ValueError):return None


def validate_live_input(industry, competitors, query):
    if not isinstance(industry,str) or not 2 <= len(industry.strip()) <= 120:
        raise ResearchError('Enter an industry or product category (2–120 characters).')
    if not isinstance(competitors,str):
        raise ResearchError('Leave competitors blank or enter up to three names, one per line.')
    names=[x.strip() for x in competitors.splitlines() if x.strip()]
    if len(names) > 3 or any(not 2 <= len(x) <= 100 for x in names):
        raise ResearchError('Competitors are optional. Enter up to three names, one per line (2–100 characters each).')
    if len(set(x.casefold() for x in names)) != len(names):
        raise ResearchError('Use distinct competitor names, one per line.')
    return {'industry':industry.strip(),'competitors':names,'query':validate_query(query)}


def analyze_live(industry, competitors, query, on_progress=lambda message: None):
    data=validate_live_input(industry,competitors,query)
    token=os.environ.get('MARKETMIND_GATEWAY_TOKEN','')
    if not token:raise ResearchError('Live research is not connected. Start the n8n-backed MarketMind service; the example remains available.')
    base=os.environ.get('MARKETMIND_LIVE_BACKEND','http://127.0.0.1:5683')
    def request(path,payload=None):
        req=urllib.request.Request(base+path,data=None if payload is None else json.dumps(payload).encode(),headers={'Content-Type':'application/json','X-MarketMind-Token':token})
        try:
            with urllib.request.urlopen(req,timeout=20) as response:return json.load(response)
        except urllib.error.HTTPError as error:
            try:message=json.loads(error.read()).get('error','Research service could not complete the request.')
            except (ValueError,UnicodeError):message='Research service could not complete the request.'
            raise ResearchError(message) from None
        except (OSError,ValueError):raise ResearchError('The research service is unavailable. Your input is kept. No automatic paid retry was made.') from None
    job=request('/research',data)['job_id']
    deadline=time.monotonic()+620
    while time.monotonic()<deadline:
        result=request('/jobs/'+job)
        on_progress(result['message'])
        if result['state']=='complete':
            report=result.get('report',{})
            generated=report.get('generated_analysis',{})
            if report.get('mode')!='live' or generated.get('provider')!='openai' or not generated.get('validation',{}).get('citations_valid') or report.get('workflow',{}).get('exit_code')!=0:
                raise ResearchError('The completed research could not be verified. No replacement report was published.')
            return report
        if result['state']=='failed':raise ResearchError(result['message'])
        time.sleep(1.5)
    raise ResearchError('Research is taking longer than expected. The original task may still finish; do not submit a duplicate immediately.')


def validate_query(query):
    if not 8 <= len(query.strip()) <= 600:
        raise ResearchError("Enter a research question between 8 and 600 characters. For example: Compare their positioning and features.")
    return query.strip()


def analyze(query):
    query = validate_query(query)
    payload = {"query": query, "analysis_provider": "openai", "save": False,
               "request_id": "a6-" + uuid.uuid4().hex}
    request = urllib.request.Request(BASE + "/analyze", data=json.dumps(payload).encode(),
                                     headers={"Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(request, timeout=150) as response:
            result = json.load(response)
    except urllib.error.HTTPError as error:
        try:
            code = json.loads(error.read()).get("code", "")
        except (ValueError, UnicodeError):
            code = ""
        if code in {"OPENAI_NOT_CONFIGURED", "OPENAI_BUDGET_DISABLED", "OPENAI_BUDGET_EXCEEDED"} or error.code == 402:
            message = "Analysis is temporarily unavailable while the owner finishes service setup or renews its allowance. Your question is still here. Please contact the owner and try again later."
        elif error.code == 429:
            message = "The research service is busy. Wait a moment, then select Generate research brief again. Your question has been kept."
        elif code in {"OPENAI_INVALID_OUTPUT", "OPENAI_INCOMPLETE"}:
            message = "The AI response did not pass our completeness or source checks. No new brief was published. Please try again or make your question more specific."
        else:
            message = "The analysis could not finish. Your question has been kept. Please try again later; if the problem continues, contact the owner."
        raise ResearchError(message) from None
    except (urllib.error.URLError, TimeoutError, OSError):
        raise ResearchError("The research service could not be reached in time. Your question has been kept. Wait a moment and try again; no replacement analysis was generated.") from None
    except (ValueError, UnicodeError):
        raise ResearchError("The research service returned an unreadable response. Please try again later.") from None
    report = result.get("report", {})
    generated = report.get("generated_analysis", {})
    if not result.get("ok") or generated.get("provider") != "openai" or not generated.get("validation", {}).get("citations_valid"):
        raise ResearchError("The analysis could not be verified. No new brief was published. Please try again later.")
    return report


COMMENT_LIMIT = ('YouTube comments are public viewer statements, not verified purchases or verified locations. '
                 'Video context does not establish that every comment concerns the named competitor. '
                 'This bounded sample cannot estimate market-wide sentiment.')


def evidence_records(report):
    """Return retained evidence, including records outside the analysis subset."""
    collection = report.get('collection') or {}
    records = collection.get('records')
    if not isinstance(records, list):
        records = report.get('selected') or []
    seen, result = set(), []
    for row in records:
        if not isinstance(row, dict) or not row.get('record_id') or row['record_id'] in seen:
            continue
        seen.add(row['record_id'])
        result.append(row)
    return result


def source_kind(row):
    return 'YouTube viewer comment' if row.get('source_type') == 'youtube_comment' else 'Public webpage' if row.get('source_type') == 'public_web_page' else 'Saved source record'


def evidence_coverage(report):
    """Normalize new coverage without mislabelling old page-only reports."""
    collection = report.get('collection') or {}
    coverage = collection.get('coverage') or {}
    web, youtube = coverage.get('web_pages') or {}, coverage.get('youtube') or {}
    selected = report.get('selected') or []
    records = evidence_records(report)
    comment_records = [row for row in records if row.get('source_type') == 'youtube_comment']
    selected_comments = sum(row.get('source_type') == 'youtube_comment' for row in selected)
    def count(data, key, default=0):
        value = data.get(key, default)
        return max(0, value) if isinstance(value, int) and not isinstance(value, bool) else default
    return {
        'web_pages': {
            'discovered': count(web, 'discovered', count(collection, 'discovered_count')),
            'readable': count(web, 'readable', count(collection, 'collected_count', len(records) - len(comment_records))),
            'analyzed': count(web, 'analyzed', len(selected) - selected_comments),
            'extraction_fallback_attempts': count(web, 'extraction_fallback_attempts'),
            'extraction_fallback_successes': count(web, 'extraction_fallback_successes'),
        },
        'youtube': {
            'status': youtube.get('status', 'available' if comment_records else 'not_collected'),
            'videos_sampled': count(youtube, 'videos_sampled', len({row.get('video_id') for row in comment_records if row.get('video_id')})),
            'comments_received': count(youtube, 'comments_received', len(comment_records)),
            'comments_retained': count(youtube, 'comments_retained', len(comment_records)),
            'comments_analyzed': count(youtube, 'comments_analyzed', selected_comments),
            'requests': count(youtube, 'requests'),
            'sampling_note': _public_text(youtube.get('sampling_note') or 'A limited sample of public comments from videos returned for each competitor search; not a representative customer survey.'),
        },
    }


def youtube_status_label(status):
    return {
        'not_configured': 'YouTube comments unavailable: connection not configured.',
        'not_collected': 'No YouTube collection is recorded for this report.',
        'disabled': 'YouTube comment collection was disabled.',
        'available': 'YouTube comments collected.',
        'ok': 'YouTube collection completed.',
        'complete': 'YouTube collection completed.',
        'completed': 'YouTube collection completed.',
        'partial': 'YouTube collection partially completed; review unavailable sources.',
        'failed': 'YouTube comments could not be collected.',
        'error': 'YouTube comments could not be collected.',
        'unavailable': 'YouTube comments could not be collected.',
        'invalid_input': 'YouTube collection could not start because the input was invalid.',
        'empty': 'No usable YouTube comments were returned.',
        'no_results': 'No usable YouTube comments were returned.',
    }.get(status, 'Review YouTube collection counts and unavailable sources below.')


def _public_text(value):
    value = str(value)
    value = re.sub(r'(?i)\b(?:sk-[a-z0-9_-]{12,}|AIza[a-z0-9_-]{20,}|fc-[a-z0-9_-]{12,}|tvly-[a-z0-9_-]{12,})', '[redacted]', value)
    value = re.sub(r'(?i)\bBearer\s+[^\s<>]+', 'Bearer [redacted]', value)
    value = re.sub(r'(?i)postgres(?:ql)?://[^\s<>]+', '[redacted connection]', value)
    return value


def _public_url(value):
    try:
        parsed = urlsplit(str(value))
        if parsed.scheme not in ('https', 'http') or not parsed.hostname or parsed.username or parsed.password:
            return ''
        params = [(k, v) for k, v in parse_qsl(parsed.query, keep_blank_values=True)
                  if k.casefold() not in {'key', 'api_key', 'apikey', 'token', 'access_token', 'authorization', 'signature'}]
        return urlunsplit((parsed.scheme, parsed.netloc, parsed.path, urlencode(params), parsed.fragment))
    except ValueError:
        return ''


def export_evidence_json(report):
    """Public evidence only: deliberately exclude runtime, config and arbitrary nested fields."""
    fields = ('record_id', 'source', 'source_type', 'brand_or_vendor', 'title', 'description_excerpt',
              'source_url', 'captured_at', 'published_at', 'price_usd_from', 'video_id', 'video_title',
              'comment_id', 'attribution_basis', 'competitor_context', 'topic_context', 'extraction_method',
              'purchaser_status', 'geography_verified')
    selected_ids = [row['record_id'] for row in report.get('selected', []) if row.get('record_id')]
    records = []
    for row in evidence_records(report):
        saved = {key: (_public_url(row[key]) if key == 'source_url' else _public_text(row[key]) if isinstance(row[key], str) else row[key])
                 for key in fields if key in row and (row[key] is None or isinstance(row[key], (str, int, float, bool)))}
        flags = row.get('flags', row.get('evidence_flags'))
        if isinstance(flags, list):
            saved['flags'] = [_public_text(flag) for flag in flags if isinstance(flag, str)]
        saved['used_in_analysis'] = row['record_id'] in selected_ids
        records.append(saved)
    failures = []
    for item in (report.get('collection') or {}).get('failures', []):
        if isinstance(item, dict):
            failures.append({key: _public_url(item[key]) if key == 'url' else _public_text(item[key])
                             for key in ('url', 'source', 'stage', 'reason', 'competitor') if isinstance(item.get(key), str)})
    result = {'format_version': 1, 'request_id': _public_text(report.get('request_id', '')),
              'generated_at': _public_text(report.get('generated_at', '')), 'query': _public_text(report.get('query', '')),
              'industry': _public_text(report.get('industry', '')),
              'competitors': [_public_text(name) for name in report.get('competitors', []) if isinstance(name, str)],
              'coverage': evidence_coverage(report), 'analysis_record_ids': selected_ids,
              'selection_note': _public_text((report.get('collection') or {}).get('selection_note') or 'Only the analysis subset informed the brief. Other retained records are provided for review.'),
              'records': records, 'unavailable_sources': failures,
              'interpretation_limits': COMMENT_LIMIT}
    return json.dumps(result, ensure_ascii=False, indent=2)


def export_html(report, notes):
    e = lambda value: html.escape(str(value), quote=True)
    content = report["generated_analysis"]["content"]
    rows = {row["record_id"]: row for row in report["selected"]}
    parts = ["<!doctype html><html lang='en'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>MarketMind research brief</title>",
             "<style>body{font:18px/1.65 system-ui,sans-serif;color:#172b28;background:#fafaf7;max-width:850px;margin:auto;padding:24px}a{color:#174d43;text-decoration:underline}a:focus-visible{outline:3px solid #9c3d10;outline-offset:4px}section{border-top:1px solid #778a81;padding:16px 0}blockquote{border-left:4px solid #174d43;padding-left:16px}pre{white-space:pre-wrap;font:inherit;overflow-wrap:anywhere}table{width:100%;border-collapse:collapse;text-align:left}th,td{padding:10px;border-bottom:1px solid #bbc6c0;vertical-align:top}caption{text-align:left;margin-bottom:10px}@media print{body{font-size:12pt}}</style><main><h1>MarketMind research brief</h1>",
             f"<p><strong>Question:</strong> {e(report['query'])}</p>",
             f"<p>Generated {e(report['generated_at'])} using {e(report['generated_analysis']['model'])}. {'Public sources collected for this request; collection dates appear below.' if report.get('mode') == 'live' else 'Saved example: October 2, 2026 snapshot. Prices are historical.'}</p>",
             f"<section><h2>Summary — {e(content['answer_status'].replace('_',' '))}</h2><p>{e(content['summary'])}</p></section>"]
    if report.get('mode') == 'live':
        coverage = evidence_coverage(report)
        web, youtube = coverage['web_pages'], coverage['youtube']
        parts.append('<section><h2>Evidence coverage</h2><table><caption>Pages and comments are separate evidence types</caption><thead><tr><th scope="col">Source type</th><th scope="col">Collected</th><th scope="col">Used in analysis</th></tr></thead><tbody>'
                     f'<tr><th scope="row">Public webpages</th><td>{web["readable"]} readable from {web["discovered"]} discovered</td><td>{web["analyzed"]}</td></tr>'
                     f'<tr><th scope="row">YouTube viewer comments</th><td>{youtube["comments_retained"]} retained from {youtube["comments_received"]} received; {youtube["videos_sampled"]} videos</td><td>{youtube["comments_analyzed"]}</td></tr></tbody></table>'
                     f'<p>{e(youtube_status_label(youtube["status"]))}</p><p>{e(youtube["sampling_note"])}</p><p>{e(COMMENT_LIMIT)}</p>'
                     '<p>Product descriptions are source claims. Viewer statements are feedback from this sample; neither is independently verified. Only the analysis subset informed the brief.</p>')
        if (report.get('collection') or {}).get('selection_note'):
            parts.append(f'<p>{e(_public_text(report["collection"]["selection_note"]))}</p>')
        failures = (report.get('collection') or {}).get('failures') or []
        if failures:
            parts.append('<h3>Unavailable sources</h3><ul>')
            for item in failures:
                parts.append(f'<li>{e(_public_url(item.get("url", "")) or item.get("source", "Source"))}: {e(_public_text(item.get("reason", "Unavailable")))}</li>')
            parts.append('</ul>')
        parts.append('</section>')
    for finding in content["findings"]:
        parts.append(f"<section><h2>{e(finding['title'])}</h2><p><strong>{e(finding['kind'].replace('_',' '))}</strong></p><p>{e(finding['analysis'])}</p><p><strong>Limit:</strong> {e(finding['caveat'])}</p>")
        for citation in finding["evidence"]:
            row = rows[citation["record_id"]]
            detail = f"{source_kind(row)} · Collected {row.get('captured_at', 'unknown')}"
            if row.get('source_type') == 'youtube_comment':
                detail += f" · Published {row.get('published_at', 'unknown')} · Competitor association is based on video context"
            parts.append(f"<blockquote>{e(citation['quote'])}</blockquote><p><a href='{e(_public_url(row['source_url']))}'>{e(row['source'])}: {e(row['title'])}</a> — {e(citation['field'])}. {e(detail)}</p>")
        parts.append("</section>")
    parts.append("<section><h2>Recommended next steps</h2><ol>")
    for item in content["recommendations"]:
        parts.append(f"<li>{e(item['action'])}<p>{e(item['rationale'])}</p><p><strong>Verify:</strong> {e(item['validation_step'])}</p></li>")
    parts.append("</ol><h2>Missing evidence</h2><ul>")
    parts.extend(f"<li>{e(gap)}</li>" for gap in content["research_gaps"])
    parts.append("</ul></section><section><h2>Product comparison checks</h2>")
    for finding in report.get("decision_audit", {}).get("findings", []):
        parts.append(f"<h3>{e(finding['title'])}</h3><p>{e(finding['claim'])}</p><p><strong>Next check:</strong> {e(finding['next_action'])}</p>")
    parts.append(f"</section><section><h2>Your review notes — not AI-verified</h2><pre>{e(notes or 'No review notes added.')}</pre></section><p>Quotes were checked against saved records. Interpretations and recommendations still require human review.</p></main></html>")
    return "\n".join(parts)
