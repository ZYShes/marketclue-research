import {collectSources} from './live-collection.mjs';
import {collectYouTube} from './youtube-collection.mjs';

/** Bounded, separately counted source channels. A failed optional channel does
 * not erase usable evidence from the other channel. No model calls here. */
export async function collectResearch(discovery,input,onProgress=()=>{},options={}) {
  const {webCollector=collectSources,youtubeCollector=collectYouTube,web={},youtube={}}=options;
  const results=await Promise.allSettled([
    webCollector(discovery,input,onProgress,web),
    youtubeCollector(input,youtube),
  ]);
  const pages=results[0].status==='fulfilled'?results[0].value:{selected:[],records:[],failures:[{source:'web',reason:'Public page collection could not complete.'}],discovered_count:discovery.sources.length,collected_count:0};
  const video=results[1].status==='fulfilled'?results[1].value:{records:[],failures:[{source:'YouTube',reason:'YouTube collection could not complete.'}],status:'unavailable',stats:{}};
  const comments=[...new Map((video.records??[]).filter(r=>r.source_type==='youtube_comment').map(r=>[r.record_id,r])).values()].slice(0,30);
  // Include the entire bounded comment sample: the pilot showed useful comments
  // were not reliably first in relevance order. The model assesses relevance;
  // video context is not proof of purchase or attribution to the target brand.
  const chosen=comments;
  const webSelected=(pages.selected??[]).slice(0,6);
  const selected=[...webSelected,...chosen];
  const coverage={
    web_pages:{discovered:pages.discovered_count,readable:pages.collected_count,analyzed:webSelected.length,extraction_fallback_attempts:pages.extraction_fallback_attempts??0,extraction_fallback_successes:pages.extraction_fallback_successes??0},
    youtube:{status:video.status,videos_sampled:video.stats?.videos_sampled??0,comments_received:video.stats?.comments_received??0,comments_retained:comments.length,comments_analyzed:chosen.length,requests:video.stats?.requests??0,sampling_note:video.stats?.sampling_note??'YouTube comments were not available.'},
  };
  return {selected,records:[...(pages.records??webSelected),...comments],failures:[...(pages.failures??[]),...(video.failures??[])],discovered_count:pages.discovered_count,collected_count:pages.collected_count,coverage,youtube_stats:video.stats??{},selection_note:'The model receives at most six page excerpts (1,800 characters each) and all retained comments (at most 30, up to 1,200 characters each). Generic praise and unrelated comments must not support product findings. Full captured records, including pages outside the analysis subset, remain in the evidence export. This small relevance-ranked sample does not estimate market-wide sentiment, verified purchase experience or geography.'};
}
