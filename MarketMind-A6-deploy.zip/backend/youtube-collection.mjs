import {createHash} from 'node:crypto';

const API_ROOT = 'https://www.googleapis.com/youtube/v3/';
const REQUEST_TIMEOUT_MS = 8_000;
const MIN_COMMENT_LENGTH = 12;
const SAMPLING_NOTE = 'At most one relevance-ranked review video per competitor and ten relevance-ranked top-level comments per video. This is a small API-selected sample, not a representative customer survey; replies are not collected. Brand attribution comes only from video search context. Purchaser status and commenter geography are not verified.';

const ERROR_REASONS = {
  comments_disabled: 'Comments are disabled for this video.',
  quota_exceeded: 'YouTube API quota is exhausted; collection stopped without retrying.',
  rate_limited: 'YouTube API rate limit reached; collection stopped without retrying.',
  authentication_failed: 'YouTube API credentials were rejected or are not permitted for this API.',
  forbidden: 'YouTube did not permit access to this resource.',
  not_found: 'The requested YouTube resource is unavailable.',
  request_failed: 'The YouTube request could not be completed.',
  request_timeout: 'The YouTube request timed out without retrying.',
  malformed_response: 'YouTube returned an unreadable or unexpected response.',
};

function errorCode(body, status) {
  const reasons = Array.isArray(body?.error?.errors) ? body.error.errors.map(item => item?.reason) : [];
  if (reasons.includes('commentsDisabled')) return 'comments_disabled';
  if (reasons.some(reason => ['quotaExceeded', 'dailyLimitExceeded', 'dailyLimitExceededUnreg'].includes(reason))) return 'quota_exceeded';
  if (status === 429 || reasons.some(reason => ['rateLimitExceeded', 'userRateLimitExceeded'].includes(reason))) return 'rate_limited';
  if (status === 401 || reasons.some(reason => ['keyInvalid', 'accessNotConfigured', 'ipRefererBlocked'].includes(reason))) return 'authentication_failed';
  if (status === 403) return 'forbidden';
  if (status === 404) return 'not_found';
  return 'request_failed';
}

// Never pass through an API error message, fetch exception, request headers, or URL.
// Google documents X-Goog-Api-Key as the header equivalent of the key parameter:
// https://docs.cloud.google.com/apis/docs/system-parameters
async function request(endpoint, parameters, apiKey, fetchImpl) {
  const url = new URL(endpoint, API_ROOT);
  for (const [name, value] of Object.entries(parameters)) url.searchParams.set(name, String(value));
  const controller = new AbortController();
  let timeout;
  const operation = (async () => {
    const response = await fetchImpl(url.href, {
      method: 'GET',
      headers: {'Accept': 'application/json', 'X-Goog-Api-Key': apiKey},
      signal: controller.signal,
      redirect: 'error',
    });
    let body;
    try { body = await response.json(); }
    catch { return {error: response.ok ? 'malformed_response' : errorCode(null, response.status)}; }
    if (!response.ok || body?.error) return {error: errorCode(body, response.status)};
    if (!body || !Array.isArray(body.items)) return {error: 'malformed_response'};
    return {items: body.items};
  })();
  // The race also bounds an injected fetch implementation that ignores AbortSignal.
  const deadline = new Promise(resolve => {
    timeout = setTimeout(() => {
      controller.abort();
      resolve({error: 'request_timeout'});
    }, REQUEST_TIMEOUT_MS);
  });
  try { return await Promise.race([operation, deadline]); }
  catch { return {error: controller.signal.aborted ? 'request_timeout' : 'request_failed'}; }
  finally { clearTimeout(timeout); }
}

function boundedOption(value, maximum) {
  return Number.isFinite(value) ? Math.max(1, Math.min(maximum, Math.floor(value))) : maximum;
}

function validID(value) {
  return typeof value === 'string' && /^[A-Za-z0-9_.-]{1,256}$/.test(value);
}

function publishedAt(value) {
  return typeof value === 'string' && Number.isFinite(Date.parse(value)) ? new Date(value).toISOString() : null;
}

/** Collect only public top-level comments through the official YouTube Data API.
 * No pagination, reply calls, or retries: at most 3 searches + 3 comment requests.
 * Options may lower the sample size, but cannot increase these hard limits.
 */
export async function collectYouTube(input, {apiKey, fetchImpl = fetch, maxVideosPerCompetitor = 1, maxCommentsPerVideo = 10} = {}) {
  const records = [], failures = [];
  const exploration = Array.isArray(input?.competitors) && input.competitors.length === 0;
  const stats = {
    requests: 0, search_requests: 0, comment_requests: 0,
    competitors_requested: Array.isArray(input?.competitors) ? input.competitors.length : 0,
    competitors_searched: 0, competitors_with_records: 0,
    topic_searches: 0,
    videos_found: 0, videos_sampled: 0,
    comments_received: 0, comments_considered: 0, records_retained: 0,
    duplicates_removed: 0, empty_comments_removed: 0, short_comments_removed: 0,
    malformed_comments_removed: 0, items_outside_limit: 0,
    max_videos_per_competitor: boundedOption(maxVideosPerCompetitor, 1),
    max_comments_per_video: boundedOption(maxCommentsPerVideo, 10),
    minimum_comment_characters: MIN_COMMENT_LENGTH,
    sampling_note: exploration ? 'At most one relevance-ranked video for the industry and research question, and ten relevance-ranked top-level comments. Topic context is not brand attribution. This is a small API-selected sample, not a representative customer survey; replies are not collected. Purchaser status and commenter geography are not verified.' : SAMPLING_NOTE,
    estimated_quota: {
      search_queries_units: 0, other_units: 0,
      note: 'Estimates count attempted requests: 1 unit per search in the separate Search Queries bucket; 1 per commentThreads request in the general bucket. Failed or aborted requests may still consume quota. Check Google Cloud for actual usage and project limits.',
      reference_url: 'https://developers.google.com/youtube/data/determine_quota_cost',
      documentation_checked_at: '2026-10-26',
    },
  };
  const result = status => {
    stats.records_retained = records.length;
    stats.estimated_quota.search_queries_units = stats.search_requests;
    stats.estimated_quota.other_units = stats.comment_requests;
    return {records, failures, status, stats};
  };
  const key = typeof apiKey === 'string' ? apiKey.trim() : '';
  const redact = value => key ? value.split(key).join('[redacted]').split(encodeURIComponent(key)).join('[redacted]') : value;
  const fail = (context, code, reason = ERROR_REASONS[code]) => {
    const safeContext = Object.fromEntries(Object.entries(context).map(([name, value]) => [name, typeof value === 'string' ? redact(value) : value]));
    failures.push({source: 'YouTube', ...safeContext, code, reason});
  };
  if (!key) {
    fail({stage: 'configuration'}, 'not_configured', 'YouTube collection is not configured: no API key is available.');
    return result('not_configured');
  }
  if (typeof input?.industry !== 'string' || !input.industry.trim() || input.industry.length > 200 ||
      !Array.isArray(input.competitors) || input.competitors.length > 3 ||
      (exploration && (typeof input.query !== 'string' || !input.query.trim() || input.query.length > 600)) ||
      input.competitors.some(name => typeof name !== 'string' || !name.trim() || name.length > 200)) {
    fail({stage: 'validation'}, 'invalid_input', 'YouTube collection requires an industry and either a research question or up to three company names.');
    return result('invalid_input');
  }
  if (typeof fetchImpl !== 'function') {
    fail({stage: 'configuration'}, 'request_failed');
    return result('unavailable');
  }

  const seenComments = new Set(), seenCompetitors = new Set();
  const competitors = input.competitors.map(name => name.trim()).filter(name => {
    const normalized = name.toLowerCase();
    if (seenCompetitors.has(normalized)) return false;
    seenCompetitors.add(normalized);
    return true;
  });
  let stopReason;
  for (const competitor of exploration ? [''] : competitors) {
    const context = exploration ? {topic_context: redact(input.industry)} : {brand_or_vendor: redact(competitor)};
    if (stopReason) {
      fail({...context, stage: 'collection'}, 'collection_stopped', 'This competitor was not requested because an earlier YouTube request reached a quota or rate limit.');
      continue;
    }
    stats.requests++;
    stats.search_requests++;
    if (exploration) stats.topic_searches++; else stats.competitors_searched++;
    const search = await request('search', {
      part: 'snippet', type: 'video', maxResults: stats.max_videos_per_competitor,
      q: exploration ? `${input.industry.trim()} ${input.query.trim()}` : `${competitor} ${input.industry.trim()} review`, safeSearch: 'moderate', order: 'relevance',
    }, key, fetchImpl);
    if (search.error) {
      fail({...context, stage: 'search'}, search.error);
      if (['quota_exceeded', 'rate_limited'].includes(search.error)) stopReason = search.error;
      continue;
    }
    const video = search.items[0];
    if (!video) {
      fail({...context, stage: 'search'}, 'no_video', 'No relevant video was returned for this research context.');
      continue;
    }
    if (!validID(video.id?.videoId) || typeof video.snippet?.title !== 'string' || !video.snippet.title.trim()) {
      fail({...context, stage: 'search'}, 'malformed_response');
      continue;
    }
    const videoId = video.id.videoId, videoTitle = video.snippet.title;
    const videoContext = {...context, stage: 'comments', video_id: videoId, url: `https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}`};
    stats.videos_found++;
    stats.requests++;
    stats.comment_requests++;
    const comments = await request('commentThreads', {
      part: 'snippet', videoId, order: 'relevance', textFormat: 'plainText', maxResults: stats.max_comments_per_video,
    }, key, fetchImpl);
    if (comments.error) {
      fail(videoContext, comments.error);
      if (['quota_exceeded', 'rate_limited'].includes(comments.error)) stopReason = comments.error;
      continue;
    }
    stats.videos_sampled++;
    stats.comments_received += comments.items.length;
    stats.items_outside_limit += Math.max(0, comments.items.length - stats.max_comments_per_video);
    const before = records.length;
    for (const thread of comments.items.slice(0, stats.max_comments_per_video)) {
      stats.comments_considered++;
      const comment = thread?.snippet?.topLevelComment;
      if (!validID(comment?.id) || !comment.snippet || typeof comment.snippet !== 'object') {
        stats.malformed_comments_removed++;
        continue;
      }
      if (seenComments.has(comment.id)) { stats.duplicates_removed++; continue; }
      seenComments.add(comment.id);
      const text = typeof comment.snippet.textOriginal === 'string' ? comment.snippet.textOriginal : comment.snippet.textDisplay;
      if (typeof text !== 'string') { stats.malformed_comments_removed++; continue; }
      if (!text.trim()) { stats.empty_comments_removed++; continue; }
      if ([...text.trim()].length < MIN_COMMENT_LENGTH) { stats.short_comments_removed++; continue; }
      records.push({
        record_id: 'yt-comment-' + createHash('sha256').update(comment.id).digest('hex').slice(0,24),
        source: 'YouTube', source_type: 'youtube_comment',
        competitor_context: competitor,
        topic_context: exploration ? input.industry.trim() : '',
        brand_or_vendor: exploration ? 'Unattributed (topic search)' : `${competitor} (video context only)`,
        title: `Comment on: ${videoTitle}`,
        description_excerpt: text,
        source_url: `${videoContext.url}&lc=${encodeURIComponent(comment.id)}`,
        captured_at: new Date().toISOString(), published_at: publishedAt(comment.snippet.publishedAt),
        price_usd_from: null, text_length: text.length,
        video_id: videoId, video_title: videoTitle, comment_id: comment.id,
        attribution_basis: exploration ? 'topic_search_only' : 'video_context_only',
        verified_purchaser: false, purchaser_status: 'unverified', geography_verified: false, geography: null,
        evidence_flags: [exploration ? 'topic_search_only' : 'video_context_only', 'purchaser_status_unverified', 'commenter_geography_unverified', 'api_relevance_sample', 'top_level_comment_only'],
      });
    }
    if (records.length > before) { if (!exploration) stats.competitors_with_records++; }
    else fail(videoContext, comments.items.length ? 'no_usable_comments' : 'no_comments', comments.items.length
      ? 'No additional usable comments remained after duplicate, empty, short, and malformed comment filtering.'
      : 'The API returned no public top-level comments for this video.');
  }
  if (records.length) return result(failures.length ? 'partial' : 'completed');
  return result(failures.some(failure => !['no_video', 'no_comments', 'no_usable_comments'].includes(failure.code)) ? 'unavailable' : 'empty');
}
