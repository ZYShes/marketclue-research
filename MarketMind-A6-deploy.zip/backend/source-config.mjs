const MAX_FALLBACK_PAGES = 3;

function key(value) { return typeof value === 'string' ? value.trim() : ''; }

function pageLimit(value, enabled) {
  if (!enabled) return 0;
  if (value === undefined || value === '') return MAX_FALLBACK_PAGES;
  const parsed = Number(value);
  return Number.isInteger(parsed) ? Math.max(0, Math.min(MAX_FALLBACK_PAGES, parsed)) : 0;
}

/** Build backend-only source settings; never return this object to the UI. */
export function sourceConfig(env = process.env) {
  const apiKey = key(env.FIRECRAWL_API_KEY);
  const allowAnonymous = env.FIRECRAWL_ALLOW_ANONYMOUS === 'true';
  return {
    youtube: {apiKey: key(env.YOUTUBE_API_KEY)},
    web: {
      extractorOptions: {apiKey, allowAnonymous},
      maxFallbackPages: pageLimit(env.FIRECRAWL_MAX_FALLBACK_PAGES, Boolean(apiKey || allowAnonymous)),
    },
  };
}

/** Explicitly allowlist status fields so credentials never reach clients. */
export function publicSourceStatus(config = sourceConfig()) {
  const options = config.web?.extractorOptions;
  const enabled = Boolean(key(options?.apiKey) || options?.allowAnonymous === true);
  return {
    youtube: {configured: Boolean(key(config.youtube?.apiKey))},
    web_extraction: {
      configured: enabled,
      provider: 'firecrawl',
      max_pages_per_run: pageLimit(config.web?.maxFallbackPages, enabled),
    },
  };
}
