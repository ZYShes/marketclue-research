import fs from 'node:fs/promises';
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { buildOpenAIRequest, generateAnalysis } from './openai-analysis.mjs';

// Standard short-context prices verified against OpenAI's pricing page on 2026-10-09.
// This is an application allowance, not the provider account's billing limit.
const RATES = { 'gpt-6-astra': { input:10, output:50 }, 'gpt-6.1-sol': { input:2, output:10 } };
const digest = value => createHash('sha256').update(value).digest('hex');
const fail = (code,status,message) => Object.assign(new Error(message),{code,status});
const dollars = units => units / 1_000_000;

export async function readOpenAIConfig(root, environment=process.env) {
  let file={};
  try {
    const text=await fs.readFile(path.join(root,'.env.local'),'utf8');
    for(const line of text.replace(/^\uFEFF/,'').split(/\r?\n/)) {
      const m=line.match(/^([A-Z][A-Z0-9_]*)=(.*)$/); if(m) file[m[1]]=m[2].trim();
    }
  } catch(error) { if(error.code!=='ENOENT') throw fail('OPENAI_CONFIG_READ_ERROR',503,'Local AI configuration could not be read.'); }
  const get = (key,fallback) => environment[key] ?? file[key] ?? fallback;
  const config={apiKey:get('OPENAI_API_KEY',''),model:get('OPENAI_MODEL','gpt-6-astra'),reasoningEffort:get('OPENAI_REASONING_EFFORT','low'),maxOutputTokens:Number(get('OPENAI_MAX_OUTPUT_TOKENS',2600)),timeoutMs:90000,budgetUsd:Number(get('OPENAI_TEST_BUDGET_USD',0))};
  if(!RATES[config.model] || !['low','medium','high','xhigh'].includes(config.reasoningEffort) || !Number.isFinite(config.budgetUsd) || config.budgetUsd<0 || config.budgetUsd>5 || !Number.isInteger(config.maxOutputTokens) || config.maxOutputTokens<128 || config.maxOutputTokens>5000) throw fail('OPENAI_INVALID_CONFIG',503,'Use a supported model/reasoning setting, 128–5000 output tokens, and a testing allowance between $0 and the authorized $5 maximum.');
  return config;
}

export function createOpenAIRuntime({root,getConfig=()=>readOpenAIConfig(root),generate=generateAnalysis,buildRequest=buildOpenAIRequest,extraInputTokens=0,toolMicrousd=0}={}) {
  const directory=process.env.MARKETMIND_LEDGER_DIR || path.join(root,'.private','openai');
  const ledgerPath=path.join(directory,'ledger.json');
  const markerPath=path.join(directory,'initialized');
  const lockPath=path.join(directory,'write.lock');
  async function atomic(file,value) {
    const temp=file+'.'+randomUUID()+'.tmp';
    const handle=await fs.open(temp,'wx',0o600);
    try {await handle.writeFile(JSON.stringify(value,null,2));await handle.sync();} finally {await handle.close();}
    await fs.rename(temp,file);
  }
  async function transaction(operation) {
    await fs.mkdir(directory,{recursive:true});
    let locked=false;
    for(let i=0;i<100;i++) {
      try {await fs.mkdir(lockPath);locked=true;break;} catch(error) {if(error.code!=='EEXIST') throw fail('OPENAI_LEDGER_UNAVAILABLE',503,'The private budget ledger is unavailable.');await new Promise(resolve=>setTimeout(resolve,20));}
    }
    if(!locked) throw fail('OPENAI_LEDGER_LOCKED',503,'The private budget ledger is locked. No paid call was started.');
    try {
      let ledger;
      try {ledger=JSON.parse(await fs.readFile(ledgerPath,'utf8'));} catch(error) {
        if(error.code!=='ENOENT') throw fail('OPENAI_LEDGER_INVALID',503,'The private budget ledger needs inspection; paid calls are stopped.');
        try {await fs.access(markerPath);throw fail('OPENAI_LEDGER_MISSING',503,'The existing budget ledger is missing; paid calls are stopped.');} catch(markerError) {if(markerError.code!=='ENOENT') throw markerError;}
        ledger={version:1,created_at:new Date().toISOString(),entries:{}};
        await atomic(ledgerPath,ledger);await fs.writeFile(markerPath,'Budget history must not be reset automatically.\n',{flag:'wx',mode:0o600});
      }
      if(ledger?.version!==1 || !ledger.entries || Array.isArray(ledger.entries) || typeof ledger.entries!=='object' || Object.values(ledger.entries).some(e=>!e || !Number.isSafeInteger(e.held_microusd)||e.held_microusd<0||!['pending','success','failed'].includes(e.state)||typeof e.hash!=='string'||(e.estimated_microusd!==null&&(!Number.isSafeInteger(e.estimated_microusd)||e.estimated_microusd<0||e.estimated_microusd!==e.held_microusd)))) throw fail('OPENAI_LEDGER_INVALID',503,'The private budget ledger needs inspection; paid calls are stopped.');
      return await operation(ledger,()=>atomic(ledgerPath,ledger));
    } catch(error) {if(error.code?.startsWith('OPENAI_')) throw error;throw fail('OPENAI_LEDGER_UNAVAILABLE',503,'Private accounting could not be saved; no automatic retry is allowed.');}
    finally {await fs.rmdir(lockPath);}
  }
  const totals=ledger=>Object.values(ledger.entries).reduce((a,e)=>({held:a.held+e.held_microusd,spent:a.spent+(e.estimated_microusd??0),uncertain:a.uncertain+(e.estimated_microusd===null||e.estimated_microusd===undefined?e.held_microusd:0),verified:a.verified||e.state==='success'}),{held:0,spent:0,uncertain:0,verified:false});
  async function status() {
    const config=await getConfig();
    return transaction(async ledger=>{
      const t=totals(ledger),limit=Math.floor(config.budgetUsd*1e6);
      return {provider:'openai',configured:Boolean(config.apiKey),model:config.model,enabled:Boolean(config.apiKey)&&limit>t.held,budget:{limit_usd:dollars(limit),remaining_usd:dollars(Math.max(0,limit-t.held)),spent_usd:dollars(t.spent),reserved_usd:dollars(t.uncertain)},live_validation:t.verified?'verified':'pending',setup_instructions:'Run configure-openai.ps1 locally, paste your own API key into its hidden prompt, then return here. No key belongs in chat. This project is capped at the authorized $5 test allowance.'};
    });
  }
  async function preflight(report) {
    const config=await getConfig();
    const body=buildRequest({...config,report});
    const rates=RATES[config.model];
    const required=Math.ceil((Buffer.byteLength(JSON.stringify(body),'utf8')+4096+extraInputTokens)*rates.input+config.maxOutputTokens*rates.output+toolMicrousd);
    const current=await status();
    return {...current,required_usd:dollars(required),can_start:current.enabled && current.budget.remaining_usd>=dollars(required)};
  }
  async function run(report) {
    const config=await getConfig();
    if(!config.apiKey) throw fail('OPENAI_NOT_CONFIGURED',503,'Configure your own OpenAI API key locally with configure-openai.ps1.');
    if(!Number.isFinite(config.budgetUsd)||config.budgetUsd<=0||config.budgetUsd>5) throw fail('OPENAI_BUDGET_DISABLED',402,'Paid analysis requires a positive allowance of at most the authorized $5.');
    if(!/^[A-Za-z0-9_-]{1,90}$/.test(report.request_id??'')) throw fail('OPENAI_REQUEST_ID_REQUIRED',400,'A unique request_id is required for paid analysis.');
    const body=buildRequest({...config,report});
    const rates=RATES[config.model];if(!rates)throw fail('OPENAI_INVALID_CONFIG',503,'No verified rate exists for the configured model.');
    const bodyText=JSON.stringify(body),hash=digest(bodyText+'\n'+report.dataset_sha256),key=digest(report.request_id);
    // UTF-8 byte count is a conservative tokenizer bound; 4096 extra tokens
    // cover message/schema framing. Output cap also covers reasoning tokens.
    const reserve=Math.ceil((Buffer.byteLength(bodyText,'utf8')+4096+extraInputTokens)*rates.input+config.maxOutputTokens*rates.output+toolMicrousd);
    const cacheFile=path.join(directory,key+'.json');
    const replay=await transaction(async(ledger,save)=>{
      const previous=ledger.entries[key];
      if(previous) {
        if(previous.hash!==hash)throw fail('OPENAI_IDEMPOTENCY_CONFLICT',409,'This request ID belongs to different input; create a new request ID.');
        if(previous.state!=='success')throw fail('OPENAI_PREVIOUS_ATTEMPT',409,'This request already started or failed. Its possible cost remains recorded; it will not be sent again automatically.');
        const result=JSON.parse(await fs.readFile(cacheFile,'utf8'));
        return {...result,cost:{...result.cost,cached_result:true}};
      }
      if(totals(ledger).held+reserve>Math.floor(config.budgetUsd*1e6))throw fail('OPENAI_BUDGET_EXCEEDED',402,'The remaining test allowance cannot cover this request safely. No API request was sent.');
      ledger.entries[key]={hash,state:'pending',model:config.model,held_microusd:reserve,estimated_microusd:null,started_at:new Date().toISOString()};await save();return null;
    });
    if(replay)return replay;
    let result;
    try {result=await generate({...config,report});} catch(error) {
      await settle(error.usage,'failed',error.response_id);throw error;
    }
    const cost=await settle(result.usage,'success',result.response_id,result);
    return {...result,cost};
    async function settle(usage,state,responseId,resultToSave) {
      const known=Number.isSafeInteger(usage?.input_tokens)&&usage.input_tokens>=0&&Number.isSafeInteger(usage?.output_tokens)&&usage.output_tokens>=0;
      const estimated=known?Math.ceil(usage.input_tokens*rates.input+usage.output_tokens*rates.output+toolMicrousd):null;
      const cost={estimated_usd:estimated===null?null:dollars(estimated),reserved_usd:estimated===null?dollars(reserve):0,cached_result:false,basis:'Standard-rate estimate; cached-input discounts ignored. Missing usage retains the conservative reservation. This is not the provider invoice.'};
      await transaction(async(ledger,save)=>{
        const entry=ledger.entries[key];if(!entry||entry.hash!==hash)throw fail('OPENAI_LEDGER_INVALID',503,'The request reservation could not be reconciled.');
        if(resultToSave)await atomic(cacheFile,{...resultToSave,cost});
        Object.assign(entry,{state,held_microusd:estimated??reserve,estimated_microusd:estimated,response_id:responseId??null,finished_at:new Date().toISOString()});await save();
      });
      return cost;
    }
  }
  return {status,run,preflight};
}
