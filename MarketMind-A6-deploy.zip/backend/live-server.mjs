import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {randomUUID,randomBytes,createHash,timingSafeEqual} from 'node:crypto';
import {spawn} from 'node:child_process';
import {createOpenAIRuntime,readOpenAIConfig} from './openai-runtime.mjs';
import {buildDiscoveryRequest,discover} from './live-discovery.mjs';
import {collectResearch} from './research-collection.mjs';
import {sourceConfig,publicSourceStatus} from './source-config.mjs';
import {validateInput} from './live-input.mjs';
export {validateInput} from './live-input.mjs';

const root=path.dirname(fileURLToPath(import.meta.url)),port=Number(process.env.MARKETMIND_LIVE_PORT??5683);
const privateDir=path.join(root,'.private','live'),jobs=new Map();
const token=process.env.MARKETMIND_GATEWAY_TOKEN;
if(!token||token.length<32)throw new Error('A server-to-server gateway token is required.');
const stageToken=randomBytes(32).toString('hex');let active=null,ready=false;
const config=()=>readOpenAIConfig(root);
const analysis=createOpenAIRuntime({root,getConfig:async()=>({...await config(),timeoutMs:120000})});
// One hosted search, at most a 128k search context, priced conservatively at
// the existing ledger's 10/50 rates. Unknown usage retains this full hold.
const search=createOpenAIRuntime({root,getConfig:async()=>({...await config(),maxOutputTokens:3500}),buildRequest:buildDiscoveryRequest,generate:discover,extraInputTokens:128000,toolMicrousd:10000});
const cli=process.env.MARKETMIND_N8N_CLI;
if(!cli)throw new Error('Set MARKETMIND_N8N_CLI to the installed n8n executable JavaScript file.');
await fs.mkdir(privateDir,{recursive:true});

const workflowId='marketmind-a6-live';
const stageNames=['input','discover','collect','analyze','complete'];
const nodes=[{id:'start',name:'Start customer research',type:'n8n-nodes-base.manualTrigger',typeVersion:1,position:[0,200],parameters:{}}];
for(const [i,stage] of stageNames.entries())nodes.push({id:stage,name:['Read customer input','Discover public sources','Collect readable evidence','MarketMind evidence analysis','Return verified brief'][i],type:'n8n-nodes-base.httpRequest',typeVersion:4.2,position:[(i+1)*250,200],parameters:{method:stage==='input'?'GET':'POST',url:`http://127.0.0.1:${port}/workflow/${stage}`,sendHeaders:true,headerParameters:{parameters:[{name:'X-Workflow-Token',value:stageToken},{name:'X-Execution-Id',value:'={{ $execution.id }}'}]},...(stage==='input'?{}:{sendBody:true,specifyBody:'json',jsonBody:'={{ JSON.stringify({job_id:$json.job_id}) }}'}),options:{timeout:300000}},retryOnFail:false,notesInFlow:true,notes:'Single attempt. The MarketMind backend validates input, sources and the shared spending allowance. No API key is stored in this workflow.'});
const connections={};for(let i=0;i<nodes.length-1;i++)connections[nodes[i].name]={main:[[{node:nodes[i+1].name,type:'main',index:0}]]};
const workflow={id:workflowId,name:'MarketMind — cross-category customer research',active:false,nodes,connections,settings:{executionOrder:'v1'},pinData:{}};
const workflowPath=path.join(privateDir,'workflow.json');await fs.writeFile(workflowPath,JSON.stringify(workflow),{mode:0o600});
const publicWorkflow=JSON.parse(JSON.stringify(workflow));for(const n of publicWorkflow.nodes.slice(1))n.parameters.headerParameters.parameters[0].value='SET_BY_LAUNCHER';
await fs.writeFile(path.join(root,'workflow_live.json'),JSON.stringify(publicWorkflow,null,2));
const childEnv={...process.env,N8N_USER_FOLDER:path.join(privateDir,'n8n'),N8N_DIAGNOSTICS_ENABLED:'false',N8N_VERSION_NOTIFICATIONS_ENABLED:'false',N8N_TEMPLATES_ENABLED:'false',N8N_PORT:'5691',N8N_RUNNERS_BROKER_PORT:'5692',N8N_RUNNERS_GRANT_TOKEN_TTL:'300'};
delete childEnv.OPENAI_API_KEY;delete childEnv.MARKETMIND_GATEWAY_TOKEN;
delete childEnv.MARKETMIND_LEDGER_DATABASE_URL;
delete childEnv.YOUTUBE_API_KEY;delete childEnv.FIRECRAWL_API_KEY;
childEnv.N8N_COMMUNITY_PACKAGES_ENABLED='false';
async function runCLI(args,name){
  const logfile=await fs.open(path.join(privateDir,name+'.log'),'w',0o600);
  return new Promise((resolve,reject)=>{
    const child=spawn(process.execPath,[cli,...args],{env:childEnv,windowsHide:true,stdio:['ignore',logfile.fd,logfile.fd]});
    const timer=setTimeout(()=>{child.kill();},600000);
    child.on('error',async()=>{clearTimeout(timer);await logfile.close();reject(new Error('n8n could not start.'));});
    child.on('exit',async code=>{clearTimeout(timer);await logfile.close();resolve(code);});
  });
}
function phase(job,state,message){job.phase=state;job.message=message;job.events.push({stage:state,message,at:new Date().toISOString()});}
async function execute(job){
  try{
    const code=await runCLI(['execute','--id='+workflowId],job.id);
    if(code!==0||!job.completed)throw new Error(job.failure||'The n8n workflow did not complete. No successful report was published.');
    job.report.workflow={engine:'n8n',workflow_id:workflowId,execution_id:job.execution_id,exit_code:code,stages:job.events};
    job.state='complete';phase(job,'complete','Your source-linked brief is ready.');
    await fs.writeFile(path.join(privateDir,job.id+'.json'),JSON.stringify(job.report,null,2),{mode:0o600});
  }catch(e){job.state='failed';phase(job,'failed',e.message);}
  finally{active=null;}
}
function authorized(value,expected){return typeof value==='string'&&value.length===expected.length&&timingSafeEqual(Buffer.from(value),Buffer.from(expected));}
function send(res,status,value){res.writeHead(status,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify(value));}
async function body(req){let size=0,chunks=[];for await(const c of req){size+=c.length;if(size>12000)throw new Error('Input is too long.');chunks.push(c);}return JSON.parse(Buffer.concat(chunks).toString());}
const server=http.createServer(async(req,res)=>{
  const url=new URL(req.url,'http://127.0.0.1');
  try{
    if(req.headers.origin)return send(res,403,{error:'Use the research interface.'});
    if(url.pathname==='/health')return send(res,200,{ready,engine:'n8n + MarketMind',model:'gpt-6-astra'});
    const isStage=url.pathname.startsWith('/workflow/');
    if(!authorized(req.headers[isStage?'x-workflow-token':'x-marketmind-token'],isStage?stageToken:token))return send(res,403,{error:'Research service authorization failed.'});
    if(req.method==='POST'&&url.pathname==='/preflight'){
      const input=validateInput(await body(req));return send(res,200,{...await search.preflight(input),sources:publicSourceStatus()});
    }
    if(url.pathname==='/status')return send(res,200,{...await analysis.status(),sources:publicSourceStatus()});
    if(req.method==='POST'&&url.pathname==='/research'){
      if(!ready)return send(res,503,{error:'The research workflow is starting. Try again shortly.'});
      if(active)return send(res,429,{error:'Another research task is running. Please wait before starting a new one.'});
      let input;try{input=validateInput(await body(req));}catch(e){return send(res,422,{error:e.message});}
      const status=await search.preflight(input);if(!status.can_start)return send(res,402,{error:'Research cannot start within the remaining test allowance. No paid request was sent.'});
      const id=randomUUID(),job={id,input,state:'running',phase:'starting',message:'Starting the research workflow.',events:[]};
      jobs.set(id,job);active=job;phase(job,'starting',job.message);void execute(job);return send(res,202,{job_id:id});
    }
    if(req.method==='GET'&&url.pathname.startsWith('/jobs/')){
      const job=jobs.get(url.pathname.slice(6));if(!job)return send(res,404,{error:'Research task not found in this service session.'});
      return send(res,200,{job_id:job.id,state:job.state,phase:job.phase,message:job.message,events:job.events,...(job.state==='complete'?{report:job.report}:{})});
    }
    if(isStage){
      const job=active,stage=url.pathname.split('/').at(-1);
      if(!job)throw new Error('No active customer request.');
      if(stage!=='input'){const b=await body(req);if(b.job_id!==job.id)throw new Error('Workflow request does not match the active task.');}
      const expected=['starting','input','discover','collect','analyze'][stageNames.indexOf(stage)];
      if(job.phase!==expected)throw new Error('Workflow stage already executed or out of order.');
      job.execution_id=String(req.headers['x-execution-id']??'');
      try{
        if(stage==='input')phase(job,'input','Preparing your market research question.');
        if(stage==='discover'){
          phase(job,'discover',job.input.competitors.length?'Searching public sources for your named companies.':'Exploring public sources for your industry and question.');
          job.discovery=await search.run({...job.input,request_id:job.id+'-search',dataset_sha256:createHash('sha256').update(JSON.stringify(job.input)).digest('hex')});
        }
        if(stage==='collect'){
          phase(job,'collect','Reading public pages and sampling YouTube comments.');
          job.collection=await collectResearch(job.discovery,job.input,p=>{job.message=`Reading sources: ${p.collected} pages collected, ${p.unavailable} unavailable. Checking YouTube comments.`;},sourceConfig());
          if(!job.collection.selected.length)throw new Error('No readable evidence was collected. Try a more specific category, location or question; no analysis was generated.');
        }
        if(stage==='analyze'){
          phase(job,'analyze','Comparing the evidence and checking every quoted excerpt.');
          const report={request_id:job.id+'-analysis',query:`Industry: ${job.input.industry}. Competitors: ${job.input.competitors.join(', ')}. Research question: ${job.input.query}`,industry:job.input.industry,competitors:job.input.competitors,mode:'live',selected:job.collection.selected,generated_at:new Date().toISOString(),dataset_sha256:createHash('sha256').update(JSON.stringify(job.collection.selected)).digest('hex'),collection:job.collection,discovery:{response_id:job.discovery.response_id,model:job.discovery.model,usage:job.discovery.usage,cost:job.discovery.cost,sources:job.discovery.sources,search_calls:job.discovery.search_calls},case:{comparability_note:'Public pages and available YouTube comments collected for this request. Collection date is not publication date. YouTube comments are viewer statements, not verified buyer feedback; brand attribution is video context only. Coverage and selection counts are explicit. Do not infer market-wide sentiment, commenter geography, market size or comparable prices without evidence.'}};
          report.generated_analysis=await analysis.run(report);job.report=report;
        }
        if(stage==='complete'){job.completed=true;phase(job,'finishing','Saving the verified research result.');}
        return send(res,200,{job_id:job.id,stage,ok:true,...(stage==='input'?job.input:{})});
      }catch(e){job.failure=e.message;throw e;}
    }
    send(res,404,{error:'Unknown research endpoint.'});
  }catch(e){send(res,e.status??500,{error:e.code?.startsWith('OPENAI_')?e.message:(e.message??'The research task failed.')});}
});
server.listen(port,'127.0.0.1',async()=>{
  const code=await runCLI(['import:workflow','--input='+workflowPath],'import');
  ready=code===0;console.log(ready?'MarketMind live workflow ready on loopback.':'n8n import failed; see private import log.');
});
