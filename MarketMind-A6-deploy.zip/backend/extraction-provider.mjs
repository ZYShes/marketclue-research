import {isIP} from 'node:net';

const ENDPOINT = 'https://api.firecrawl.dev/v2/scrape';
const MAX_RESPONSE_BYTES = 2_000_000;
const MAX_TEXT_CHARS = 100_000;
const MAX_TITLE_CHARS = 500;
const MAX_TIMEOUT_MS = 25_000;

class ExtractionError extends Error {
  constructor(code, message) {
    super(message);
    this.name = 'ExtractionError';
    this.code = code;
    this.provider = 'firecrawl';
  }
}

function fail(code, message) { throw new ExtractionError(code, message); }

function publicURL(value) {
  if (typeof value !== 'string' || value.length > 2048 || /[\s\\\u0000-\u001f\u007f]/u.test(value)) {
    fail('UNSAFE_SOURCE_URL', 'Only public HTTPS source pages are supported.');
  }
  let url;
  try { url = new URL(value); } catch { fail('UNSAFE_SOURCE_URL', 'Only public HTTPS source pages are supported.'); }
  const host = url.hostname.toLowerCase().replace(/\.$/, '');
  const labels = host.split('.');
  if (url.protocol !== 'https:' || url.username || url.password || (url.port && url.port !== '443') ||
      isIP(host.replace(/^\[|\]$/g, '')) || host.length > 253 || labels.length < 2 ||
      labels.some(label => !/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label)) ||
      !/[a-z]/.test(labels.at(-1)) || /(?:^|\.)(?:localhost|local|internal|lan|home|invalid|test)$/.test(host)) {
    fail('UNSAFE_SOURCE_URL', 'Only public HTTPS source pages are supported.');
  }
  url.hostname = host;
  url.hash = '';
  return url;
}

function rejectProviderRouting(url) {
  // These domains have separately priced data-provider routes rather than ordinary page scraping.
  if (/(?:^|\.)(?:linkedin\.com|x\.com|twitter\.com)$/.test(url.hostname)) {
    fail('EXTRACTOR_UNSUPPORTED_SOURCE', 'This source is outside the basic page extraction budget.');
  }
}

async function readJSON(response, signal) {
  const length = Number(response.headers?.get('content-length'));
  if (Number.isFinite(length) && length > MAX_RESPONSE_BYTES) {
    void response.body?.cancel().catch(() => {});
    fail('EXTRACTOR_RESPONSE_TOO_LARGE', 'The extraction response exceeds the size limit.');
  }
  // A streaming body is required so a misleading or missing Content-Length cannot bypass the cap.
  if (!response.body?.getReader) fail('EXTRACTOR_INVALID_RESPONSE', 'The extraction provider returned an invalid response.');
  const reader = response.body.getReader();
  const cancel = () => { void reader.cancel().catch(() => {}); };
  signal.addEventListener('abort', cancel, {once: true});
  const chunks = [];
  let size = 0;
  try {
    while (true) {
      const {done, value} = await reader.read();
      if (signal.aborted) fail('EXTRACTOR_TIMEOUT', 'The extraction provider timed out.');
      if (done) break;
      size += value.byteLength;
      if (size > MAX_RESPONSE_BYTES) {
        cancel();
        fail('EXTRACTOR_RESPONSE_TOO_LARGE', 'The extraction response exceeds the size limit.');
      }
      chunks.push(value);
    }
    try { return JSON.parse(Buffer.concat(chunks, size).toString('utf8')); }
    catch { fail('EXTRACTOR_INVALID_RESPONSE', 'The extraction provider returned an invalid response.'); }
  } finally {
    signal.removeEventListener('abort', cancel);
    reader.releaseLock();
  }
}

function documentResult(payload, requestedURL) {
  if (payload?.success !== true || !payload.data || typeof payload.data !== 'object') {
    fail('EXTRACTOR_FAILED', 'The extraction provider could not retrieve the source.');
  }
  const {data} = payload;
  const metadata = data.metadata;
  if (!metadata || typeof metadata !== 'object') {
    fail('EXTRACTOR_INVALID_RESPONSE', 'The extraction provider returned an invalid response.');
  }
  // API success does not mean the source page loaded successfully.
  const status = metadata.statusCode;
  if (!Number.isInteger(status) || !((status >= 200 && status < 300) || status === 304) || metadata.error) {
    fail('EXTRACTOR_SOURCE_UNAVAILABLE', 'The source did not return a readable public page.');
  }
  if (metadata.provider) fail('EXTRACTOR_UNSUPPORTED_SOURCE', 'This source is outside the basic page extraction budget.');
  if (metadata.contentType && (typeof metadata.contentType !== 'string' || !/^(?:text\/(?:html|plain)|application\/xhtml\+xml)(?:;|$)/i.test(metadata.contentType))) {
    fail('EXTRACTOR_UNSUPPORTED_SOURCE', 'This source format is not supported by the page extractor.');
  }
  // Validate every supplied URL, not just the field chosen for provenance.
  for (const field of ['url', 'sourceURL', 'finalURL']) {
    if (metadata[field] !== undefined) rejectProviderRouting(publicURL(metadata[field]));
  }
  const returnedURL = metadata.finalURL ?? metadata.url ?? metadata.sourceURL;
  if (!returnedURL) fail('EXTRACTOR_INVALID_RESPONSE', 'The extraction provider did not identify the source URL.');
  const url = publicURL(returnedURL).href;
  if (typeof data.markdown !== 'string' || !data.markdown.trim()) {
    fail('EXTRACTOR_EMPTY_TEXT', 'The extraction provider returned no readable source text.');
  }
  const markdown = data.markdown.trim();
  const text = markdown.slice(0, MAX_TEXT_CHARS);
  return {
    url,
    requested_url: requestedURL.href,
    title: typeof metadata.title === 'string' ? metadata.title.replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, MAX_TITLE_CHARS) : '',
    text,
    text_length: text.length,
    truncated: markdown.length > text.length,
    provider: 'firecrawl',
  };
}

/**
 * Supplement a caller-approved public page with extracted markdown. The caller must check
 * DNS/network safety and robots policy before invoking this adapter and recheck returned
 * URL provenance before accepting it. Extraction does not verify identity or location.
 *
 * REST reference: https://docs.firecrawl.dev/api-reference/endpoint/scrape
 * There is no documented maxCredits parameter on /scrape. This sends one basic request,
 * disables per-page document parsing, and never retries; it is not a billing guarantee.
 */
export async function extractWithFirecrawl(value, {apiKey, fetchImpl = fetch, allowAnonymous = false, timeoutMs = MAX_TIMEOUT_MS} = {}) {
  const requestedURL = publicURL(value);
  rejectProviderRouting(requestedURL);
  if (apiKey !== undefined && (typeof apiKey !== 'string' || apiKey.length > 512 || /\s/.test(apiKey))) {
    fail('EXTRACTOR_INVALID_CONFIG', 'The extraction provider configuration is invalid.');
  }
  if (!apiKey && allowAnonymous !== true) fail('EXTRACTOR_NOT_CONFIGURED', 'The extraction provider is not configured.');
  if (typeof fetchImpl !== 'function' || !Number.isInteger(timeoutMs) || timeoutMs < 1000 || timeoutMs > MAX_TIMEOUT_MS) {
    fail('EXTRACTOR_INVALID_CONFIG', 'The extraction provider configuration is invalid.');
  }
  const headers = {'Content-Type': 'application/json', Accept: 'application/json'};
  if (apiKey) headers.Authorization = `Bearer ${apiKey}`;
  const controller = new AbortController();
  let timer;
  const deadline = new Promise((_, reject) => {
    timer = setTimeout(() => {
      controller.abort();
      reject(new ExtractionError('EXTRACTOR_TIMEOUT', 'The extraction provider timed out.'));
    }, timeoutMs);
  });
  try {
    return await Promise.race([deadline, (async () => {
      const response = await fetchImpl(ENDPOINT, {
        method: 'POST', headers, redirect: 'error', signal: controller.signal,
        body: JSON.stringify({
          url: requestedURL.href, formats: ['markdown'], onlyMainContent: true,
          proxy: 'basic', parsers: [], skipTlsVerification: false,
          timeout: timeoutMs, maxAge: 0, storeInCache: false,
        }),
      });
      if (!response?.ok || response.redirected || (response.url && response.url !== ENDPOINT)) {
        void response?.body?.cancel().catch(() => {});
        const code = response?.status === 429 ? 'EXTRACTOR_RATE_LIMITED' : 'EXTRACTOR_FAILED';
        fail(code, code === 'EXTRACTOR_RATE_LIMITED' ? 'The extraction provider rate limit was reached.' : 'The extraction provider could not retrieve the source.');
      }
      return documentResult(await readJSON(response, controller.signal), requestedURL);
    })()]);
  } catch (error) {
    if (error instanceof ExtractionError) throw error;
    if (controller.signal.aborted) fail('EXTRACTOR_TIMEOUT', 'The extraction provider timed out.');
    // Never expose request headers, provider bodies, or upstream error messages/cause.
    fail('EXTRACTOR_FAILED', 'The extraction provider could not retrieve the source.');
  } finally {
    clearTimeout(timer);
    controller.abort();
  }
}
