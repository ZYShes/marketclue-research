// Optional durable accounting adapter. Not enabled in the cloud preview.
// The existing ledger must be migrated explicitly; this module never resets it.
export function createPostgresTransaction({connectionString, createClient}={}) {
  const failure=()=>Object.assign(new Error('Durable budget storage is unavailable. No automatic paid retry is allowed.'),{code:'OPENAI_LEDGER_UNAVAILABLE',status:503});
  return async function transaction(operation) {
    let client;
    try {
      if(createClient) client=await createClient();
      else {
        const {Client}=await import('pg');
        client=new Client({connectionString,connectionTimeoutMillis:10000,statement_timeout:15000});
      }
      await client.connect();
      await client.query('BEGIN');
      await client.query("SET LOCAL lock_timeout = '5s'");
      const result=await client.query('SELECT document FROM marketmind_budget WHERE id=$1 FOR UPDATE',['a6-shared']);
      if(result.rows.length!==1)throw failure();
      const ledger=result.rows[0].document;
      if(ledger?.version!==1||!ledger.entries||Array.isArray(ledger.entries)||typeof ledger.entries!=='object'||Object.values(ledger.entries).some(e=>!e||!Number.isSafeInteger(e.held_microusd)||e.held_microusd<0||!['pending','success','failed'].includes(e.state)||typeof e.hash!=='string'||(e.estimated_microusd!==null&&(!Number.isSafeInteger(e.estimated_microusd)||e.estimated_microusd<0||e.estimated_microusd!==e.held_microusd))))throw failure();
      const value=await operation(ledger,async()=>{
        await client.query('UPDATE marketmind_budget SET document=$1::jsonb, updated_at=now() WHERE id=$2',[JSON.stringify(ledger),'a6-shared']);
      });
      await client.query('COMMIT');
      return value;
    } catch(error) {
      if(client)try{await client.query('ROLLBACK');}catch{}
      if(error.code?.startsWith('OPENAI_'))throw error;
      throw failure(); // Do not expose connection strings or database errors.
    } finally {
      if(client)try{await client.end();}catch{}
    }
  };
}
