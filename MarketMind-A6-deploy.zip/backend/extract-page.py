"""Bounded HTML extraction for MarketMind's source-aware research stages.

Independent adapter following Madison MarketMind's search/extract/evidence design;
does not execute page JavaScript or treat search summaries as page evidence.
"""
import sys, json, re, html
from html.parser import HTMLParser

class Extractor(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.skip=[]; self.parts=[]; self.title=[]; self.in_title=False
    def handle_starttag(self, tag, attrs):
        if tag in ('script','style','nav','footer','noscript','svg'):
            self.skip.append(tag)
        if tag=='title': self.in_title=True
        if tag in ('p','div','li','section','h1','h2','h3','br'): self.parts.append('\n')
    def handle_endtag(self, tag):
        if self.skip and self.skip[-1]==tag: self.skip.pop()
        if tag=='title': self.in_title=False
        if tag in ('p','div','li','section','h1','h2','h3'): self.parts.append('\n')
    def handle_data(self, data):
        if self.in_title: self.title.append(data)
        elif not self.skip: self.parts.append(data+' ')

if __name__=='__main__':
    data=json.load(sys.stdin); parser=Extractor();parser.feed(data['html'])
    lines=list(dict.fromkeys(re.sub(r'\s+',' ',x).strip() for x in ''.join(parser.parts).splitlines()))
    lines=[x for x in lines if len(x)>25]
    words=set(re.findall(r'[\w]{3,}',data.get('query','').lower()))|{'pricing','price','features','plan','customers','product','team'}
    ranked=sorted(enumerate(lines),key=lambda item:sum(w in item[1].lower() for w in words),reverse=True)
    chosen=sorted(ranked[:10]); excerpt=' '.join(x[1] for x in chosen)[:1800]
    print(json.dumps({'title':' '.join(parser.title).strip()[:700],'text':excerpt,'text_length':sum(map(len,lines))},ensure_ascii=True))
