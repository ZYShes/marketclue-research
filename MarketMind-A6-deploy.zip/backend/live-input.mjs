// Shared live request validation; importing this module never starts a server.
export function validateInput(x){
  if(!x||typeof x!=='object')throw new Error('Enter an industry and a research question.');
  const clean=(v,min,max,label)=>{if(typeof v!=='string'||v.trim().length<min||v.trim().length>max)throw new Error(label);return v.trim();};
  const industry=clean(x.industry,2,120,'Enter an industry or product category (2–120 characters).');
  const query=clean(x.query,8,600,'Enter a research question between 8 and 600 characters.');
  const names=x.competitors===undefined?[]:x.competitors;
  if(!Array.isArray(names)||names.length>3)throw new Error('Competitors are optional. Enter up to three names.');
  const competitors=names.map(v=>clean(v,2,100,'Each competitor needs a name of 2–100 characters.'));
  if(new Set(competitors.map(x=>x.toLowerCase())).size!==competitors.length)throw new Error('Use distinct competitor names.');
  return {industry,query,competitors};
}
