import https from 'node:https';
import dns from 'node:dns/promises';
import net from 'node:net';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';

const blocked=new net.BlockList();
for(const [ip,bits] of [['0.0.0.0',8],['10.0.0.0',8],['100.64.0.0',10],['127.0.0.0',8],['169.254.0.0',16],['172.16.0.0',12],['192.0.0.0',24],['192.0.2.0',24],['192.168.0.0',16],['198.18.0.0',15],['198.51.100.0',24],['203.0.113.0',24],['224.0.0.0',4],['240.0.0.0',4]])blocked.addSubnet(ip,bits);
export function safeURL(value) {
  const u=new URL(value);
  if(u.protocol!=='https:'||u.username||u.password||(u.port&&u.port!=='443')||net.isIP(u.hostname)||u.hostname==='localhost'||!u.hostname.includes('.')) throw new Error('Only public HTTPS source pages are supported.');
  u.hash=''; return u;
}
async function get(value) {
  const u=safeURL(value),addresses=await dns.lookup(u.hostname,{all:true,family:4});
  if(!addresses.length||addresses.some(x=>blocked.check(x.address)))throw new Error('Private or reserved source address rejected.');
  // Pin the checked IP on the actual socket; redirects are checked separately.
  return new Promise((resolve,reject)=>{
    const req=https.get(u,{headers:{'User-Agent':'MarketMindResearch/1.0','Accept':'text/html,text/plain'},lookup:(host,opts,cb)=>opts.all?cb(null,[{address:addresses[0].address,family:4}]):cb(null,addresses[0].address,4)},res=>{
      let size=0, chunks=[];
      res.on('data',d=>{size+=d.length;if(size>2_000_000){req.destroy(new Error('Source page exceeds the collection size limit.'));return;}chunks.push(d);});
      res.on('end',()=>resolve({status:res.statusCode,location:res.headers.location,type:res.headers['content-type']??'',text:Buffer.concat(chunks).toString('utf8')}));res.on('error',reject);
    });
    req.setTimeout(10000,()=>req.destroy(new Error('Source page timed out.')));req.on('error',reject);
  });
}
export function robotsAllowed(text,pathname) {
  let agents=[], rules=[], groupRules=[],inRules=false;
  const finish=()=>{if(agents.some(a=>a==='*'||'marketmindresearch'.includes(a)))rules.push(...groupRules);};
  for(const line of text.split(/\r?\n/)){
    const m=line.split('#')[0].trim().match(/^([^:]+):\s*(.*)$/);if(!m)continue;
    const key=m[1].toLowerCase(),value=m[2].trim();
    if(key==='user-agent'){if(inRules){finish();agents=[];groupRules=[];inRules=false;}agents.push(value.toLowerCase());}
    else if(key==='disallow'||key==='allow'){inRules=true;if(value)groupRules.push({allow:key==='allow',path:value});}
  } finish();
  const applicable=rules.filter(r=>{const pattern=r.path.replace(/[.+?^{}()|[\]\\]/g,'\\$&').replaceAll('*','.*');return new RegExp('^'+pattern).test(pathname);}).sort((a,b)=>b.path.length-a.path.length||Number(b.allow)-Number(a.allow));
  return !applicable.length||applicable[0].allow;
}
async function page(value) {
  let u=safeURL(value);
  for(let i=0;i<4;i++){
    const robots=await get(u.origin+'/robots.txt');
    if(robots.status===200&&!robotsAllowed(robots.text,u.pathname+u.search))throw new Error('Collection disallowed by robots.txt.');
    if(robots.status!==200&&robots.status!==404)throw new Error('Robots policy could not be verified.');
    const r=await get(u.href);
    if([301,302,303,307,308].includes(r.status)&&r.location){u=safeURL(new URL(r.location,u).href);continue;}
    if(r.status!==200)throw new Error('Source unavailable (HTTP '+r.status+').');
    if(!/text\/html|application\/xhtml/i.test(r.type))throw new Error('This source format is not supported by the HTML collector.');
    if(/just a moment|verify you are human|captcha|access denied/i.test(r.text.slice(0,12000))&&r.text.length<60000)throw new Error('Source requires interactive access.');
    return {url:u.href,html:r.text};
  } throw new Error('Too many source redirects.');
}
function extract(html,query) {
  return new Promise((resolve,reject)=>{
    const p=spawn(process.env.MARKETMIND_PYTHON??'python',['-X','utf8',fileURLToPath(new URL('./extract-page.py',import.meta.url))],{windowsHide:true,stdio:['pipe','pipe','pipe']});
    let out='';p.stdout.on('data',x=>out+=x);p.on('error',reject);p.on('exit',code=>{try{if(code)throw new Error('Source extraction failed.');resolve(JSON.parse(out));}catch(e){reject(e);}});p.stdin.end(JSON.stringify({html,query}));
  });
}
export async function collectSources(discovery,input,onProgress=()=>{}) {
  const successes=[], failures=[];
  const candidates=discovery.sources.slice(0,12);
  for(let i=0;i<candidates.length;i+=3){
    await Promise.all(candidates.slice(i,i+3).map(async source=>{
      try{
        const fetched=await page(source.url),data=await extract(fetched.html,input.query+' '+input.industry+' '+input.competitors.join(' '));
        if(data.text.length<120)throw new Error('Insufficient readable source text.');
        const host=new URL(fetched.url).hostname;
        successes.push({record_id:'web-'+createHash('sha256').update(fetched.url).digest('hex').slice(0,20),source:host,brand_or_vendor:host,title:data.title||source.title||host,description_excerpt:data.text,source_url:fetched.url,captured_at:new Date().toISOString(),price_usd_from:null,source_type:'public_web_page',text_length:data.text_length});
      }catch(e){failures.push({url:source.url,reason:/source|robots|public|Private|Collection|Insufficient|Too many/i.test(e.message)?e.message:'The public page could not be retrieved.'});}
    }));
    onProgress({collected:successes.length,unavailable:failures.length});
  }
  const ordered=[];const used=new Set();
  for(const name of input.competitors){
    const tokens=name.toLowerCase().match(/[\p{L}\p{N}]{3,}/gu)??[name.toLowerCase()];
    const matches=successes.filter(r=>tokens.some(t=>(r.title+' '+r.source_url+' '+r.description_excerpt).toLowerCase().includes(t)));
    for(const r of matches.slice(0,2))if(!used.has(r.record_id)){ordered.push(r);used.add(r.record_id);}
  }
  for(const r of successes)if(!used.has(r.record_id)){ordered.push(r);used.add(r.record_id);}
  return {selected:ordered.slice(0,6),failures,discovered_count:candidates.length,collected_count:successes.length};
}
