import https from 'node:https';
import dns from 'node:dns/promises';
import net from 'node:net';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {extractWithFirecrawl} from './extraction-provider.mjs';

const blocked=new net.BlockList();
for(const [ip,bits] of [['0.0.0.0',8],['10.0.0.0',8],['100.64.0.0',10],['127.0.0.0',8],['169.254.0.0',16],['172.16.0.0',12],['192.0.0.0',24],['192.0.2.0',24],['192.168.0.0',16],['198.18.0.0',15],['198.51.100.0',24],['203.0.113.0',24],['224.0.0.0',4],['240.0.0.0',4]])blocked.addSubnet(ip,bits);
export function safeURL(value) {
  const u=new URL(value);
  if(u.protocol!=='https:'||u.username||u.password||(u.port&&u.port!=='443')||net.isIP(u.hostname)||u.hostname==='localhost'||!u.hostname.includes('.')) throw new Error('Only public HTTPS source pages are supported.');
  u.hash=''; return u;
}
const REQUEST_DEADLINE_MS=10_000,COLLECTION_DEADLINE_MS=210_000;
const STOPPED='Source collection timed out or was cancelled.';
const NETWORK_FAILURE='The public page could not be retrieved.';
function sourceError(message){return Object.assign(new Error(message),{name:'SourceCollectionError'});}
function timeoutLimit(value,maximum){return Number.isFinite(value)&&value>0?Math.min(maximum,Math.max(1,Math.floor(value))):maximum;}
function deadlineScope(parent,timeoutMs){
  const controller=new AbortController(),abort=()=>controller.abort();
  const timer=setTimeout(abort,timeoutMs);
  if(parent?.aborted)abort();else parent?.addEventListener('abort',abort,{once:true});
  return {signal:controller.signal,dispose(){clearTimeout(timer);parent?.removeEventListener('abort',abort);}};
}
function requireActive(signal,message=STOPPED){if(signal?.aborted)throw sourceError(message);}
// The lazy callback is never started after cancellation, including injected
// implementations that do not themselves implement AbortSignal.
function abortable(operation,signal,message=STOPPED){
  return new Promise((resolve,reject)=>{
    if(signal?.aborted){reject(sourceError(message));return;}
    let settled=false;
    const finish=(error,value)=>{if(settled)return;settled=true;signal?.removeEventListener('abort',abort);error?reject(error):resolve(value);};
    const abort=()=>finish(sourceError(message));
    signal?.addEventListener('abort',abort,{once:true});
    Promise.resolve().then(()=>{requireActive(signal,message);return operation();}).then(value=>finish(null,value),error=>finish(error));
  });
}
/** One public HTTPS request, with a hard deadline covering DNS and streaming.
 * Injectable transport functions support offline cancellation tests. */
export async function fetchSource(value,{signal,timeoutMs=REQUEST_DEADLINE_MS,lookupImpl=dns.lookup,requestImpl=https.get}={}) {
  const scope=deadlineScope(signal,timeoutLimit(timeoutMs,REQUEST_DEADLINE_MS));
  const timedOut='Source page timed out.';
  try{
    return await abortable(async()=>{
      const u=safeURL(value);
      const addresses=await abortable(()=>lookupImpl(u.hostname,{all:true,family:4}),scope.signal,timedOut);
      requireActive(scope.signal,timedOut);
      if(!Array.isArray(addresses)||!addresses.length||addresses.some(x=>net.isIP(x?.address)!==4||blocked.check(x.address)))throw sourceError('Private or reserved source address rejected.');
      // Pin the checked IP on the actual socket; redirects are checked separately.
      return new Promise((resolve,reject)=>{
        let req,res,settled=false;
        const finish=(error,value)=>{if(settled)return;settled=true;scope.signal.removeEventListener('abort',abort);error?reject(error):resolve(value);};
        const stop=error=>{if(settled)return;finish(error);req?.destroy();res?.destroy();};
        const abort=()=>stop(sourceError(timedOut));
        scope.signal.addEventListener('abort',abort,{once:true});
        try{
          requireActive(scope.signal,timedOut);
          req=requestImpl(u,{headers:{'User-Agent':'MarketMindResearch/1.0','Accept':'text/html,text/plain'},lookup:(host,opts,cb)=>opts.all?cb(null,[{address:addresses[0].address,family:4}]):cb(null,addresses[0].address,4)},response=>{
            res=response;
            if(scope.signal.aborted){abort();return;}
            let size=0;const chunks=[];
            res.on('data',chunk=>{if(settled)return;size+=chunk.length;if(size>2_000_000){stop(sourceError('Source page exceeds the collection size limit.'));return;}chunks.push(chunk);});
            res.on('end',()=>finish(null,{status:res.statusCode,location:res.headers.location,type:res.headers['content-type']??'',text:Buffer.concat(chunks).toString('utf8')}));
            res.on('error',()=>stop(sourceError(NETWORK_FAILURE)));
            res.on('aborted',()=>stop(sourceError(NETWORK_FAILURE)));
          });
          req.on('error',()=>stop(sourceError(NETWORK_FAILURE)));
          if(scope.signal.aborted)abort();
        }catch(error){stop(error?.name==='SourceCollectionError'?error:sourceError(NETWORK_FAILURE));}
      });
    },scope.signal,timedOut);
  }catch(error){
    if(error?.name==='SourceCollectionError')throw error;
    throw sourceError(NETWORK_FAILURE);
  }finally{scope.dispose();}
}
export function robotsAllowed(text,pathname) {
  let agents=[], groupRules=[],inRules=false;const groups=[];
  const finish=()=>{if(agents.length)groups.push({agents:[...agents],rules:[...groupRules]});};
  for(const line of text.split(/\r?\n/)){
    const m=line.split('#')[0].trim().match(/^([^:]+):\s*(.*)$/);if(!m)continue;
    const key=m[1].toLowerCase(),value=m[2].trim();
    if(key==='user-agent'){if(inRules){finish();agents=[];groupRules=[];inRules=false;}agents.push(value.toLowerCase());}
    else if(key==='disallow'||key==='allow'){inRules=true;if(value)groupRules.push({allow:key==='allow',path:value});}
  } finish();
  const named=groups.filter(g=>g.agents.some(a=>a!=='*'&&'marketmindresearch'.includes(a)));
  const rules=(named.length?named:groups.filter(g=>g.agents.includes('*'))).flatMap(g=>g.rules);
  const normalize=value=>value.replace(/%([0-9a-f]{2})/gi,(all,hex)=>{const ch=String.fromCharCode(parseInt(hex,16));return /[A-Za-z0-9._~-]/.test(ch)?ch:all.toUpperCase();});
  const target=normalize(pathname);
  const applicable=rules.filter(r=>{const pattern=normalize(r.path).replace(/[.+?^{}()|[\]\\]/g,'\\$&').replaceAll('*','.*');return new RegExp('^'+pattern).test(target);}).sort((a,b)=>normalize(b.path).length-normalize(a.path).length||Number(b.allow)-Number(a.allow));
  return !applicable.length||applicable[0].allow;
}
export async function checkSourcePolicy(value,{signal,getImpl=fetchSource}={}) {
  requireActive(signal);
  const u=safeURL(value);
  // The robots request checks and pins the same host's DNS within its deadline.
  const robots=await abortable(()=>getImpl(u.origin+'/robots.txt',{signal}),signal);
  requireActive(signal);
  if(robots.status===200&&!robotsAllowed(robots.text,u.pathname+u.search))throw new Error('Collection disallowed by robots.txt.');
  if(robots.status!==200&&robots.status!==404)throw new Error('Robots policy could not be verified.');
  return u;
}
async function page(value,{signal}={}) {
  let u=safeURL(value);
  for(let i=0;i<4;i++){
    requireActive(signal);
    await checkSourcePolicy(u.href,{signal});
    const r=await fetchSource(u.href,{signal});
    if([301,302,303,307,308].includes(r.status)&&r.location){u=safeURL(new URL(r.location,u).href);continue;}
    if(r.status!==200)throw new Error('Source unavailable (HTTP '+r.status+').');
    if(!/text\/html|application\/xhtml/i.test(r.type))throw new Error('This source format is not supported by the HTML collector.');
    if(/just a moment|verify you are human|captcha|access denied/i.test(r.text.slice(0,12000))&&r.text.length<60000)throw new Error('Source requires interactive access.');
    return {url:u.href,html:r.text};
  } throw new Error('Too many source redirects.');
}
function extract(html,query,{signal}={}) {
  return new Promise((resolve,reject)=>{
    if(signal?.aborted){reject(sourceError(STOPPED));return;}
    const p=spawn(process.env.MARKETMIND_PYTHON??'python',['-X','utf8',fileURLToPath(new URL('./extract-page.py',import.meta.url))],{windowsHide:true,stdio:['pipe','pipe','pipe']});
    let out='',settled=false;
    const finish=(error,value)=>{if(settled)return;settled=true;signal?.removeEventListener('abort',abort);error?reject(error):resolve(value);};
    const abort=()=>{p.kill();finish(sourceError(STOPPED));};
    signal?.addEventListener('abort',abort,{once:true});
    p.stdout.on('data',x=>out+=x);
    p.on('error',()=>finish(sourceError('Source extraction failed.')));
    p.stdin.on('error',()=>finish(sourceError('Source extraction failed.')));
    p.on('exit',code=>{try{if(code)throw new Error();finish(null,JSON.parse(out));}catch{finish(sourceError('Source extraction failed.'));}});
    if(signal?.aborted)abort();else p.stdin.end(JSON.stringify({html,query}));
  });
}
const publicFailures=new Set([STOPPED,NETWORK_FAILURE,'Only public HTTPS source pages are supported.','Private or reserved source address rejected.','Source page exceeds the collection size limit.','Source page timed out.','Collection disallowed by robots.txt.','Robots policy could not be verified.','This source format is not supported by the HTML collector.','Source requires interactive access.','Too many source redirects.','Source extraction failed.','Insufficient readable source text.']);
function publicFailure(error){return publicFailures.has(error?.message)||/^Source unavailable \(HTTP [1-5][0-9]{2}\)\.$/.test(error?.message??'')?error.message:NETWORK_FAILURE;}
export async function collectSources(discovery,input,onProgress=()=>{},options={}) {
  const successes=[], failures=[];
  const {pageImpl=page,extractImpl=extract,providerImpl=extractWithFirecrawl,checkPolicyImpl=checkSourcePolicy,extractorOptions={}}=options;
  const fallbackEnabled=Boolean(extractorOptions.apiKey||extractorOptions.allowAnonymous===true);
  const fallbackLimit=fallbackEnabled?Math.max(0,Math.min(3,Number.isInteger(options.maxFallbackPages)?options.maxFallbackPages:3)):0;
  let fallbackAttempts=0,fallbackSuccesses=0;
  const candidates=discovery.sources.slice(0,12);
  const collectionTimeoutMs=timeoutLimit(options.collectionTimeoutMs,COLLECTION_DEADLINE_MS);
  const scope=deadlineScope(options.signal,collectionTimeoutMs),signal=scope.signal;
  const deadline=performance.now()+collectionTimeoutMs;
  try{
  for(let i=0;i<candidates.length;i+=3){
    if(signal.aborted){for(const source of candidates.slice(i))failures.push({url:source.url,reason:STOPPED});break;}
    await Promise.all(candidates.slice(i,i+3).map(async source=>{
      try{
        requireActive(signal);
        // A denied, private, login or CAPTCHA page never reaches the provider.
        const fetched=await abortable(()=>pageImpl(source.url,{signal}),signal);
        let data,extractionMethod='direct_html',finalURL=fetched.url;
        try{data=await abortable(()=>extractImpl(fetched.html,input.query+' '+input.industry+' '+input.competitors.join(' '),{signal}),signal);}catch{requireActive(signal);data={text:'',title:''};}
        requireActive(signal);
        if((data?.text?.length??0)<120&&fallbackAttempts<fallbackLimit){
          const remainingMs=Math.floor(deadline-performance.now());
          if(remainingMs<1000)throw sourceError(STOPPED);
          requireActive(signal);
          fallbackAttempts++;
          const providerOptions={...extractorOptions,signal,timeoutMs:Math.min(remainingMs,timeoutLimit(extractorOptions.timeoutMs,25000))};
          const result=await abortable(()=>providerImpl(fetched.url,providerOptions),signal);
          requireActive(signal);
          await abortable(()=>checkPolicyImpl(result.url,{signal}),signal);
          requireActive(signal);
          if(/verify you are human|access denied|captcha|sign in to continue/i.test(result.text.slice(0,1500))&&result.text.length<10000)throw new Error('Source requires interactive access.');
          data=result;finalURL=result.url;extractionMethod='firecrawl';
          if(data.text.length>=120)fallbackSuccesses++;
        }
        if(data.text.length<120)throw new Error('Insufficient readable source text.');
        const host=new URL(finalURL).hostname;
        successes.push({record_id:'web-'+createHash('sha256').update(finalURL).digest('hex').slice(0,20),source:host,brand_or_vendor:host,title:data.title||source.title||host,description_excerpt:data.text.slice(0,100000),source_url:finalURL,captured_at:new Date().toISOString(),price_usd_from:null,source_type:'public_web_page',text_length:data.text.length,extraction_method:extractionMethod});
      }catch(e){failures.push({url:source.url,reason:publicFailure(e)});}
    }));
    onProgress({collected:successes.length,unavailable:failures.length});
  }
  }finally{scope.dispose();}
  // Redirect aliases may resolve to the same evidence: retain one record.
  const unique=[...new Map(successes.map(row=>[row.record_id,row])).values()];
  const ordered=[];const used=new Set();
  for(const name of input.competitors){
    const tokens=name.toLowerCase().match(/[\p{L}\p{N}]{3,}/gu)??[name.toLowerCase()];
    const matches=unique.filter(r=>tokens.some(t=>(r.title+' '+r.source_url+' '+r.description_excerpt).toLowerCase().includes(t)));
    for(const r of matches.slice(0,2))if(!used.has(r.record_id)){ordered.push(r);used.add(r.record_id);}
  }
  for(const r of unique)if(!used.has(r.record_id)){ordered.push(r);used.add(r.record_id);}
  return {selected:ordered.slice(0,6),records:unique,failures,discovered_count:candidates.length,collected_count:unique.length,extraction_fallback_attempts:fallbackAttempts,extraction_fallback_successes:fallbackSuccesses};
}
