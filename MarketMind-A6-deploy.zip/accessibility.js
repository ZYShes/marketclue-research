// Add semantics around Streamlit's native controls without replacing their behavior.
export default function(component) {
  window.mmA11yObserver?.disconnect();
  const state = component.data;
  const titles = {preferences:'A little moreyour way.',home:'See the marketdifferently.',research:'What do youwant to know?',sources:'Go to the source.',results:'A clearer perspective.'};
  const attr = (node,name,value) => { if(node && node.getAttribute(name)!==value) node.setAttribute(name,value); };
  let popoverWasOpen=false;
  const update = () => {
    const popoverOpen=!!document.querySelector('[data-testid="stPopoverBody"]');
    if(popoverWasOpen && !popoverOpen) requestAnimationFrame(()=>{
      if(document.activeElement===document.body) document.querySelector('[data-testid="stPopoverButton"]')?.focus();
    });
    popoverWasOpen=popoverOpen;
    const preferenceButton=document.querySelector('[data-testid="stPopoverButton"]');
    preferenceButton?.parentElement?.removeAttribute('aria-expanded');
    preferenceButton?.parentElement?.removeAttribute('aria-haspopup');
    attr(preferenceButton,'aria-expanded',String(popoverOpen));
    attr(preferenceButton,'aria-haspopup','dialog');
    const preferencePanel=document.querySelector('[data-testid="stPopoverBody"]');
    attr(preferencePanel,'role','dialog'); attr(preferencePanel,'aria-label','Reading and motion settings');
    document.querySelectorAll('[aria-activedescendant][aria-expanded="false"]').forEach(node=>{
      if(!document.getElementById(node.getAttribute('aria-activedescendant'))) node.removeAttribute('aria-activedescendant');
    });
    const main=document.querySelector('[data-testid="stMain"]');
    attr(main,'role','main'); attr(main,'aria-label','MarketMind workspace');
    const nav=document.querySelector('.st-key-masthead');
    attr(nav,'role','navigation'); attr(nav,'aria-label','Primary');
    nav?.querySelectorAll('button').forEach(button => {
      const current=button.textContent.trim().toLowerCase()===state.view;
      if(current) attr(button,'aria-current','page'); else button.removeAttribute('aria-current');
    });
    const heading=document.querySelector('h1#start');
    if(heading && heading.textContent.trim()===titles[state.view] && state.revision>0 && window.mmFocusedRevision!==state.revision){
      window.mmFocusedRevision=state.revision;
      heading.focus({preventScroll:true});
      heading.scrollIntoView({block:'start',behavior:'instant'});
    }
    const query=document.querySelector('textarea[aria-label="Your research question"]');
    const error=document.querySelector('[data-testid="stAlertContentError"]');
    const industry=document.querySelector('input[aria-label="Industry or product category"]');
    const competitors=document.querySelector('textarea[aria-label="Competitors — one per line"]');
    const fields=[industry,competitors,query].filter(Boolean);
    const invalidFields=fields.filter(field=>{
      const value=field.value.trim();
      if(field===industry) return value.length<2 || value.length>120;
      if(field===competitors){const names=value.split(/\n/).map(x=>x.trim()).filter(Boolean);return names.length<1 || names.length>3 || names.some(x=>x.length<2||x.length>100) || new Set(names.map(x=>x.toLowerCase())).size!==names.length;}
      return value.length<8 || value.length>600;
    });
    if(query){
      if(error) attr(error,'id','question-error');
      for(const field of fields){
        attr(field,'aria-invalid',String(!!error && invalidFields.includes(field)));
        attr(field,'aria-required','true');
        attr(field,'aria-describedby',error?'question-help question-error':'question-help');
      }
      const errorText=error?.textContent;
      if(error && invalidFields.length && errorText!==window.mmLastQuestionError){
        invalidFields[0].focus();
        window.mmLastQuestionError=errorText;
      }
      if(!error) window.mmLastQuestionError=null;
    }
    const running=document.getElementById('research-progress');
    if(running && !window.mmProgressFocused){
      window.mmProgressFocused=true;
      running.focus({preventScroll:true});
      running.scrollIntoView({block:'center',behavior:'instant'});
    }
    if(!running) window.mmProgressFocused=false;
  };
  let queued=false;
  window.mmA11yObserver=new MutationObserver(()=>{
    if(!queued){ queued=true; requestAnimationFrame(()=>{queued=false;update();}); }
  });
  window.mmA11yObserver.observe(document.body,{childList:true,subtree:true});
  update();
  const restorePopoverFocus = event => {
    if(event.key==='Escape' && document.querySelector('[data-testid="stPopoverBody"]')) {
      requestAnimationFrame(()=>requestAnimationFrame(()=>{
        if(!document.querySelector('[data-testid="stPopoverBody"]')) document.querySelector('[data-testid="stPopoverButton"]')?.focus();
      }));
    }
  };
  document.addEventListener('keydown',restorePopoverFocus,true);
return () => { window.mmA11yObserver?.disconnect(); document.removeEventListener("keydown",restorePopoverFocus,true); };
}
