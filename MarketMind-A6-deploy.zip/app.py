import re
import json
import html
import hashlib
from pathlib import Path
import streamlit as st
from client import ResearchError, analyze, analyze_live, validate_live_input, export_html, research_budget

# Keep research fields when Streamlit removes widgets on another view.
for field in ('industry', 'competitor_names', 'query'):
    if field in st.session_state:
        st.session_state[field] = st.session_state[field]

def md(value):
    return re.sub(r"([\\`*_\[\]<>$])", r"\\\1", str(value))

TASKS = {
    "Compare similar products": "How do the three merchants position 48 by 24 by 24 inch enclosures on starting price and stated features?",
    "Find products under $200": "Which standalone glass enclosures have saved starting prices below $200?",
    "Write my own question": "",
}

def go(view):
    if 'query' in st.session_state:
        st.session_state.draft = st.session_state.query
    st.session_state.view = view
    st.session_state.entered = view != 'home'
    st.session_state.nav_revision = st.session_state.get('nav_revision', 0) + 1

def finish_preferences(use_defaults=False):
    if use_defaults:
        for key in ('large_text', 'spaced_text', 'reduce_motion'):
            st.session_state[key] = False
        st.session_state.magnification = 100
    st.session_state.preferences_done = True
    go('home')


def open_example():
    st.session_state.research_mode = 'example'
    go('sources')


def open_live():
    st.session_state.research_mode = 'live'
    go('research')


def choose_task(task):
    st.session_state.task = task
    st.session_state.query = TASKS[task]
    st.session_state.draft = TASKS[task]

def remember_draft():
    st.session_state.draft = st.session_state.query
    st.session_state.pop('error', None)

def reading_controls():
    st.checkbox("Larger text", key="large_text")
    st.checkbox("More space between lines", key="spaced_text")
    st.checkbox("Reduce motion", key="reduce_motion")
    st.selectbox('Page magnification', [100, 150, 200], format_func=lambda value: f'{value}%', key='magnification')
    st.caption("Settings stay with you during this session.")

def render_report(report):
    live = report.get("mode") == "live"
    generated = report["generated_analysis"]
    content = generated["content"]
    sources = {row["record_id"]: row for row in report["selected"]}
    st.html('<p class="mm-status" role="status" aria-live="polite">Your brief is ready. Continue to step 2, Review your brief.</p>')
    st.header("2. Review your brief", anchor="results")
    labels = {"supported": "Evidence found", "partial": "Some evidence is missing", "insufficient_evidence": "Not enough evidence"}
    st.write("**" + labels.get(content["answer_status"], "Review required") + "**")
    with st.expander("Read the overview", expanded=True):
        st.write(md(content["summary"]))
    if live:
        st.caption('Public pages collected for this request. Quotes are checked against captured text; claims and recommendations still need review.')
        st.caption('Industry: ' + report['industry'] + ' · Competitors: ' + ', '.join(report['competitors']))
        with st.expander('Research coverage & unavailable sources'):
            collection=report['collection']
            st.write(f"{collection['discovered_count']} candidate pages · {collection['collected_count']} readable pages · {len(report['selected'])} pages in the analysis")
            for item in collection['failures']:
                st.write(md(item['url']) + ' — ' + md(item['reason']))
            st.caption('Some sources may be inaccessible or irrelevant. This is a bounded research brief, not an exhaustive market study.')
    else:
        st.info('Saved example report — generated earlier, not a new search or an answer to a new question.')
        st.caption("Before using a price claim: verify the exact product, included parts and delivery cost.")
    st.write("Open a finding to read its explanation and sources.")
    kinds = {"source_observation": "What the source says" if live else "What the seller says", "interpretation": "AI interpretation — check before use", "hypothesis": "An idea to test"}
    fields = {"title": "Product name", "description_excerpt": "Captured page excerpt" if live else "Seller description", "price_usd_from": "Saved starting price (USD)", "captured_at": "Date collected (UTC)"}
    for i, finding in enumerate(content["findings"], 1):
        with st.expander(f"Finding {i}: {md(finding['title'])}"):
            st.caption(kinds[finding["kind"]])
            st.write(md(finding["analysis"]))
            st.write("**Important limit:** " + md(finding["caveat"]))
            st.subheader(f"Sources for finding {i}")
            for record_id in dict.fromkeys(c["record_id"] for c in finding["evidence"]):
                row = sources[record_id]
                st.write(f"**{md(row['source'])} — {md(row['title'])}**")
                for citation in finding["evidence"]:
                    if citation["record_id"] == record_id:
                        st.write("**" + fields.get(citation["field"], "Saved evidence") + ":** " + md(citation["quote"]))
                st.link_button(f"Visit {row['source']}: {row['title']} (new tab)", row["source_url"])
    with st.expander("Next steps & missing evidence"):
        for i, item in enumerate(content["recommendations"], 1):
            st.write(f"**{i}. {md(item['action'])}**")
            st.write(md(item["rationale"]))
            st.write("**Verify:** " + md(item["validation_step"]))
        if content["research_gaps"]:
            st.subheader("Evidence still missing")
            for gap in content["research_gaps"]:
                st.write("• " + md(gap))
    with st.expander("Detailed comparison checks"):
        for finding in report.get("decision_audit", {}).get("findings", []):
            st.subheader(md(finding["title"]))
            st.write(md(finding["claim"]))
            st.write("**Next check:** " + md(finding["next_action"]))
        retrieval = report.get("retrieval") or {}
        for condition in retrieval.get("constraints", []):
            st.write(md(condition.get("description", condition.get("type", "Comparison condition"))))
        for warning in retrieval.get("warnings", []):
            st.write(md(warning))
        st.caption(f"Generated with {generated['model']} · {len(sources)} listings · {report['generated_at'][:10]} UTC")
        st.write("**Question answered:** " + md(report["query"]))
    st.header("3. Save your brief", anchor="save")
    note_key = "notes_" + report["request_id"]
    if note_key not in st.session_state:
        st.session_state[note_key] = st.session_state.get("saved_" + note_key, "")
    with st.expander("Add your notes (optional)"):
        st.caption("Notes go into your download. They are not sent to the AI.")
        with st.form("review_notes"):
            st.text_area("Your review notes (optional)", key=note_key, height=105, max_chars=5000,
                         placeholder="What should your team verify next?")
            saved = st.form_submit_button("Save notes to brief")
        if saved:
            st.session_state["saved_" + note_key] = st.session_state[note_key]
            st.success("Notes saved to this brief. Download it below to keep a copy.")
    st.download_button("Download brief (HTML)", data=export_html(report, st.session_state.get(note_key, "")),
                       file_name="MarketMind-research-brief.html", mime="text/html")
    st.caption("Includes all findings, sources and limits — even sections you did not open.")
    with st.expander("How to open or print your download"):
        st.write("1. Open the downloaded HTML file in your browser.")
        st.write("2. To make a PDF, select Print, then Save as PDF.")
        st.write("Download before closing this page. Session notes are not saved permanently.")


st.set_page_config(page_title="MarketMind — A clearer perspective", page_icon="◒", layout="wide")
st.html('<style>' + Path(__file__).with_name('ui.css').read_text(encoding='utf-8') + '</style>')
if st.session_state.get('large_text'):
    st.html('<style>.stMain p,.stMain li,.stMain label,.stMain textarea,.stMain input,.stMain summary,.stMain button{font-size:1.25rem!important}</style>')
if st.session_state.get('spaced_text'):
    st.html('<style>.stMain p,.stMain li,.stMain label,.stMain textarea{line-height:2!important;letter-spacing:.12em;word-spacing:.16em}.stMain p{margin-bottom:2em!important}</style>')
if st.session_state.get('reduce_motion'):
    st.html('<style>*,*::before,*::after{animation:none!important;transition:none!important;scroll-behavior:auto!important}.stMain button:hover{transform:none!important}</style>')
# Keep preferences independent of widget cleanup between the welcome and workspace views.
for preference in ('large_text', 'spaced_text', 'reduce_motion', 'magnification'):
    if preference in st.session_state:
        st.session_state[preference] = st.session_state[preference]
view = st.session_state.get('view', 'research' if st.session_state.get('entered') else 'home')
if not st.session_state.get('preferences_done') and 'view' not in st.session_state and not st.session_state.get('entered'):
    view = 'preferences' 
st.set_page_config(page_title={'preferences':'Reading preferences','home':'Home','research':'Research','sources':'Sources','results':'Your brief'}.get(view,'Research') + ' — MarketMind')
scale=st.session_state.get('magnification',100)
st.html(f'<span hidden data-mm-scale="{scale}"></span>')
a11y_js=Path(__file__).with_name('accessibility.js').read_text(encoding='utf-8')
a11y = st.components.v2.component('marketmind_accessibility_' + hashlib.sha256(a11y_js.encode()).hexdigest()[:10], js=a11y_js)
a11y(data={'view':view,'revision':st.session_state.get('nav_revision',0)},key='accessibility',height=0)
st.html('<a class="mm-skip" href="#start">Skip to main content</a>')
if view == 'preferences':
    with st.container(key='welcome-preferences'):
        st.html('<div class="wordmark"><span aria-hidden="true">◒</span> marketmind</div>')
        st.html('<div class="pref-intro"><span>MAKE YOURSELF AT HOME</span><h1 id="start" tabindex="-1">A little more<br><em>your way.</em></h1><p>Choose what feels comfortable. Change it anytime.</p></div>')
        choices, preview = st.columns([1, 1.15], gap='large')
        with choices:
            st.checkbox('Larger text', key='large_text')
            st.checkbox('More space between lines', key='spaced_text')
            st.checkbox('Reduce motion', key='reduce_motion')
        with preview:
            large = st.session_state.get('large_text', False)
            spaced = st.session_state.get('spaced_text', False)
            reduced = st.session_state.get('reduce_motion', False)
            st.html(f'''<section class="pref-preview" aria-label="Reading preview">
                <span class="pref-label">LIVE PREVIEW</span><div class="pref-mark" aria-hidden="true"></div>
                <h2>Less noise.<br>More perspective.</h2>
                <p>Compare products. Follow the evidence.<br>Make your next move with confidence.</p>
                </section>''')
            settings = ('Larger text' if large else 'Standard text') + ' · ' + ('Extra spacing' if spaced else 'Standard spacing') + ' · ' + ('Motion reduced' if reduced else 'Gentle motion')
            st.html('<p class="pref-feedback" role="status" aria-live="polite">' + settings + '</p>')
        with st.container(key='preference-actions'):
            st.button('Save & enter →', type='primary', on_click=finish_preferences, use_container_width=True)
            st.button('Skip — use defaults', on_click=finish_preferences, args=(True,), use_container_width=True)
        st.html('<p class="pref-footnote">Your choices stay with you during this session.</p>')
    st.stop()

with st.container(key='masthead'):
    brand, nav, access = st.columns([1.4,2.2,1.2])
    with brand:
        edition = 'PREVIEW / SAVED SAMPLE REPORT' if st.session_state.get('preview_fixture') else 'LIVE RESEARCH / STUDIO'
        st.html(f'<div class="wordmark"><span aria-hidden="true">◒</span> marketmind<span class="edition">{edition}</span></div>')
    with nav:
        a,b,c = st.columns(3)
        a.button('Home',on_click=go,args=('home',),use_container_width=True)
        b.button('Research',on_click=go,args=('research',),use_container_width=True)
        c.button('Sources',on_click=go,args=('sources',),use_container_width=True)
    with access:
        with st.popover('Reading & motion',use_container_width=True):
            reading_controls()

if view == 'home':
    with st.container(key='landing'):
        mode=st.session_state.get('lens_mode','01 / Ask')
        stage={'01 / Ask':('ask','Start with a better question.','Compare a price. Explore a feature. Find a starting point.'),
               '02 / Trace':('trace','Follow the evidence.','Every finding leads back to a saved seller source.'),
               '03 / Decide':('decide','Make room for judgment.','See the limits, add your notes, and take your brief with you.')}[mode]
        st.html(f'''<section class="hero hero-{stage[0]}" aria-labelledby="start">
          <div class="hero-meta"><span>AN INDEPENDENT VIEW OF YOUR MARKET</span><span>VOL. 01 — PRODUCT RESEARCH</span></div>
          <div class="hero-type"><h1 id="start" tabindex="-1">See the market<br><em>differently.</em></h1><p>From scattered product information<br>to a perspective you can explain.</p></div>
          <div class="lens-scene" aria-hidden="true"><div class="axis axis-x"></div><div class="axis axis-y"></div><div class="lens lens-back"></div><div class="lens lens-front"><i></i><b></b></div><div class="lens-core"></div><span class="coordinate coordinate-a">01 — QUESTION</span><span class="coordinate coordinate-b">02 — EVIDENCE</span><span class="coordinate coordinate-c">03 — PERSPECTIVE</span></div>
          <div class="hero-bottom"><span>LESS NOISE. MORE CONTEXT.</span><span aria-hidden="true">↙ EXPLORE THE PROCESS</span></div>
        </section>''')
        st.radio('Explore the process', ['01 / Ask','02 / Trace','03 / Decide'],horizontal=True,key='lens_mode',label_visibility='collapsed',width='stretch')
        with st.container(key='process-caption'):
            st.html(f'<div class="process-copy" role="status"><h2>{stage[1]}</h2><p>{stage[2]}</p></div>')
        actions, scope=st.columns([1,2])
        with actions:
            st.button('Start a research brief ↗',type='primary',on_click=open_live,use_container_width=True)
        with scope:
            st.html('<p class="scope-note">YOUR MARKET<br><strong>Your industry. Your competitors.</strong><br>Search public sources and build a brief with evidence.</p>')
    st.button('Explore the saved reptile example →',on_click=open_example)
    st.stop()

if view == 'sources':
    if st.session_state.get('research_mode','live') != 'example':
        st.html('<div class="chapter"><span>YOUR EVIDENCE / 02</span><h1 id="start" tabindex="-1">Go to the source.</h1><p>The public pages behind your latest research.</p></div>')
        report=st.session_state.get('report')
        if report and report.get('mode')=='live':
            for row in report['selected']:
                with st.expander(row['source'] + ' — ' + row['title']):
                    st.write(md(row['description_excerpt']))
                    st.caption('Collected ' + row['captured_at'][:10] + ' · public page; source claims are not independently verified')
                    st.link_button('Open source (new tab)',row['source_url'])
            st.button('Return to your brief →',on_click=go,args=('results',))
        else:
            st.write('Start a research brief to collect sources for your industry.')
            st.button('Start research ↗',type='primary',on_click=open_live)
        st.button('Explore the saved reptile example →',on_click=open_example)
        st.stop()
    st.html('<div class="chapter"><span>OPTIONAL EXAMPLE / OCTOBER 2026</span><h1 id="start" tabindex="-1">Go to the source.</h1><p>Browse the records behind the research.</p></div>')
    with st.container(key='source-stage'):
        catalog = json.loads(Path(__file__).with_name('backend').joinpath('data/catalog.json').read_text(encoding='utf-8'))
        merchants = list(dict.fromkeys(row['source'] for row in catalog))
        merchant = st.radio("Choose a merchant", merchants, horizontal=True, key="source_merchant")
        rows = [row for row in catalog if row['source'] == merchant]
        selected_id = st.selectbox("Explore a saved listing", [row['record_id'] for row in rows], format_func=lambda rid: next(row['title'] for row in rows if row['record_id'] == rid), key="listing_" + merchant)
        row = next(row for row in rows if row['record_id'] == selected_id)
        e = html.escape
        price = row.get('price_usd_from')
        price_label = f"${price:,.2f}" if isinstance(price, (int, float)) else "Not recorded"
        st.html(f'''<div class="mm-product"><div class="mm-product-art" aria-hidden="true"><div class="mm-cube"><i></i><b></b></div><span>FIELD NOTES / 01</span></div><div class="mm-product-copy"><span>{e(merchant)}</span><h2>{e(row['title'])}</h2><strong>{price_label}</strong><p>Saved starting price · USD</p></div></div>''')
        with st.expander("Read the seller's saved description"):
            st.write(row['description_excerpt'])
            st.link_button("Open this seller listing (new tab)", row['source_url'])
        st.caption("October 2, 2026 snapshot. Prices are not live; listings may include bundles or accessories. Illustration is schematic.")



    if st.button('Open saved example brief',type='primary'):
        st.session_state.report=json.loads(Path(__file__).with_name('example-report.json').read_text(encoding='utf8'))
        go('results')
        st.rerun()
    st.button('Research your own industry →',on_click=open_live)
    st.stop()

if view == 'results' and st.session_state.get('report'):
    st.html('<div class="chapter"><span>YOUR RESEARCH / 03</span><h1 id="start" tabindex="-1">A clearer perspective.</h1><p>Read the finding. Follow the source. Decide what comes next.</p></div>')
    st.button('← Edit your question',on_click=go,args=('research',))
    with st.container(key='report-sheet'):
        render_report(st.session_state.report)
    st.stop()

st.html('<div class="chapter"><span>YOUR RESEARCH / 01</span><h1 id="start" tabindex="-1">What do you<br><em>want to know?</em></h1><p>Your industry. Your competitors. A clearer perspective.</p></div>')
st.session_state.research_mode='live'
with st.container(key='question-stage'):
    st.text_input('Industry or product category',key='industry',max_chars=120,placeholder='e.g. Project management software')
    st.text_area('Competitors — one per line',key='competitor_names',height=110,max_chars=302,placeholder='Asana\nTrello\nMonday.com')
    if 'query' not in st.session_state:
        st.session_state.query=st.session_state.get('draft','')
    query=st.text_area('Your research question',key='query',height=130,max_chars=600,placeholder='How do these competitors differ in positioning, features and pricing?',on_change=remember_draft)
    st.html('<p id="question-help" class="question-help">One to three competitors. Your inputs and public evidence are sent to OpenAI. Avoid private information.</p>')
    budget_state=research_budget(st.session_state.industry,st.session_state.competitor_names,query)
    budget_blocked=False
    if budget_state:
        allowance=budget_state['budget']
        st.caption(f"Test allowance: USD {allowance['remaining_usd']:.2f} remaining of USD {allowance['limit_usd']:.2f}. Usage is estimated; this is not an upfront charge.")
        budget_blocked=budget_state.get('can_start',budget_state['enabled']) is False
        if budget_blocked:
            st.warning('Not enough test allowance to start safely. No paid request will be sent. The saved example is still available.')
    submitted=st.button('Research my market ↗',type='primary',use_container_width=True,disabled=budget_blocked)
    st.caption('Search → Read sources → Compare evidence. Usually a few minutes. Some websites may be unavailable.')
    with st.expander('What will this research include?'):
        st.write('Publicly discoverable pages relevant to your industry and competitors. The brief separates source observations, interpretations and missing evidence. It does not promise access to every website, exhaustive research, or verified customer sentiment.')
    st.button('Explore the saved reptile example →',on_click=open_example)
    if st.session_state.get('report'):
        st.button('Return to your saved brief →',on_click=go,args=('results',))
    if submitted:
        st.session_state.draft=query
        st.session_state.pop('error',None)
        try:
            validate_live_input(st.session_state.industry,st.session_state.competitor_names,query)
            with st.status('Starting your research.',expanded=True) as progress:
                def update_progress(message):
                    progress.update(label=message,state='running')
                report=analyze_live(st.session_state.industry,st.session_state.competitor_names,query,on_progress=update_progress)
                st.session_state.report=report
                progress.update(label='Your brief is ready.',state='complete')
            go('results')
            st.rerun()
        except ResearchError as error:
            if 'progress' in locals():
                progress.update(label='Research could not finish.',state='error')
            st.session_state.error=str(error)
    if st.session_state.get('error'):
        st.error(st.session_state.error)
